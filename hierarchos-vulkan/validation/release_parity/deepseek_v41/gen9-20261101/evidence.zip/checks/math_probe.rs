#![allow(dead_code)]
#[path = "../../hierarchos-vulkan/src/vulkan.rs"]
mod vulkan;
use anyhow::{Context, Result};
use serde::Deserialize;
use std::path::Path;
use vulkan::{ComputeKernel, GpuBuffer, VulkanDevice};

#[derive(Deserialize)]
struct Case {
    name: String,
    shader: String,
    push: Vec<u32>,
    grid: [u32; 3],
    buffers: Vec<Vec<u32>>,
    output: usize,
    expected: Vec<u32>,
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let cases: Vec<Case> = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let device = VulkanDevice::new()?;
    let mut results = Vec::new();
    for c in cases {
        let kernel = ComputeKernel::new(&device, &std::fs::read(Path::new(&c.shader))?,
            c.buffers.len(), (c.push.len() * 4) as u32)?;
        let buffers = c.buffers.iter().map(|b| GpuBuffer::from_u32(&device, b))
            .collect::<Result<Vec<_>>>()?;
        let mut batch = device.compute_batch()?;
        kernel.record_dispatch(&mut batch, &buffers.iter().collect::<Vec<_>>(),
            bytemuck::cast_slice(&c.push), c.grid)?;
        batch.submit()?;
        let actual = buffers.get(c.output).context("output index")?.read_u32(c.expected.len())?;
        let count = actual.iter().zip(&c.expected).filter(|(a,b)| a!=b).count();
        let worst = actual.iter().zip(&c.expected).map(|(&a,&b)|
            (f32::from_bits(a) as f64-f32::from_bits(b) as f64).abs()).fold(0.0f64, f64::max);
        eprintln!("{}: {} differences / {}, max_abs={worst:e}",c.name,count,actual.len());
        results.push(serde_json::json!({"name":c.name,"differences":count,"max_abs":worst,"actual":actual}));
    }
    std::fs::write(&args[2], serde_json::to_vec_pretty(&results)?)?;
    Ok(())
}
