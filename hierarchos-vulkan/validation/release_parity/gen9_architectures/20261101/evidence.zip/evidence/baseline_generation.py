import json
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, str(Path('hierarchos-vulkan/validation').resolve()))
from qualify_gen9_architectures import compare_logits, digest, words, write_json
root = Path('target/gen9-phase3/cpu-generation-complete').resolve()
manifest = json.loads((root/'manifest.json').read_text())
assert manifest['complete']
out = Path('target/gen9-phase3/baseline-generation').resolve()
out.mkdir(exist_ok=False)
binary = Path('target/gen9-phase3/baseline-bin/transformer_generation_parity.exe').resolve()
result = {'scope': 'resident-only baseline diagnostics, not storage qualification',
          'binary_sha256': digest(binary), 'records': []}
for case in manifest['cases']:
    expected = json.loads((root/case['cpu']).read_text())
    for cached in [False, True]:
        label = case['family'] + ('-cache' if cached else '-full')
        report = out/(label+'.json')
        command = [str(binary), '--model', str(Path(manifest['fixture_root'])/case['package']),
            '--fixture', str(root/case['input']), '--output', str(report), '--use-cache', str(cached).lower()]
        record = {'family': case['family'], 'cached': cached, 'pass': False}
        try:
            process = subprocess.run(command,capture_output=True,text=True,timeout=180)
            (out/(label+'.log')).write_text(process.stdout+process.stderr)
            assert process.returncode == 0, f'exit={process.returncode}'
            actual = json.loads(report.read_text())
            ref = expected[str(cached).lower()]
            assert actual['sequence'] == ref['sequence'], 'sequence differs'
            checks = [compare_logits(words(a), b, [True]*len(b)) for a,b in zip(actual['logits'],ref['bits'],strict=True)]
            record.update(max_abs=max(c['max_abs'] for c in checks),pass_=all(c['pass'] for c in checks))
            record['pass'] = record.pop('pass_')
        except Exception as error:
            record['error'] = str(error)
        result['records'].append(record)
        write_json(out/'diagnostic.json', result)
        print(record, flush=True)
