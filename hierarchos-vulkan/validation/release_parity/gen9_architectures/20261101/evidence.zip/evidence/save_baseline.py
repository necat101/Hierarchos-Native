import pathlib,shutil,hashlib,json
r=pathlib.Path.cwd();out=r/'target/gen9-phase3/baseline-bin';out.mkdir(exist_ok=False);rows={}
for stem in ['hierarchos-vulkan-transformer-logits','parameter_streaming_bench','transformer_generation_parity']:
 p=r/'hierarchos-vulkan/target/release'/(stem+'.exe');q=out/p.name;shutil.copy2(p,q);rows[p.name]=hashlib.sha256(q.read_bytes()).hexdigest()
(out/'binaries.json').write_text(json.dumps(rows,indent=2))
f=json.loads((r/'target/gen9-phase3/cpu-fixtures/manifest.json').read_text());print('oracle status',f['oracle']['transformers_status']);print('saved baseline executables',list(rows))
