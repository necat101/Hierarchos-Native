from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
root = Path('target/gen9-phase3').resolve()
source = Path('hierarchos-vulkan/target/debug/deps/hierarchos_vulkan-25096d1b6b51d860.exe').resolve()
binary = root/'candidate-bin/unit-tests-corrected.exe'
assert not binary.exists()
shutil.copy2(source,binary)
result = {'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'pass':False,'records':[]}
for index, selection in enumerate(['t5_native_encoder_loader_and_seq2seq_facade_use_source_side_contract',
        'parameter_streaming::','qwen3_next_gated_delta_end_to_end_backward_matches_finite_difference']):
    command = [str(binary), selection, '--nocapture', '--test-threads=1']
    path = root/f'regression-final-{index}.log'
    with path.open('w') as log:
        process = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    match = re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',path.read_text())
    record = {'selection':selection,'command':command,'exit':process.returncode,'log':path.name}
    if match:
        record.update(status=match[1],passed=int(match[2]),failed=int(match[3]),ignored=int(match[4]))
    record['pass'] = process.returncode==0 and match is not None and record['passed']>0
    result['records'].append(record)
    (root/'regressions-final.json').write_text(json.dumps(result,indent=2)+'\n')
    print(record,flush=True)
result['pass'] = all(record['pass'] for record in result['records'])
(root/'regressions-final.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['pass'] else 1)
