from pathlib import Path
import hashlib
import json
import shutil
import sys
out = Path('target/gen9-phase3/candidate-bin')
out.mkdir(exist_ok=True)
metadata = out/'binaries.json'
hashes = json.loads(metadata.read_text()) if metadata.exists() else {}
for name in sys.argv[1:]:
    source = Path('hierarchos-vulkan/target/release')/(name+'.exe')
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    destination = out/source.name
    if destination.exists():
        assert hashlib.sha256(destination.read_bytes()).hexdigest() == before
    else:
        shutil.copy2(source, destination)
    assert before == hashlib.sha256(destination.read_bytes()).hexdigest() == hashlib.sha256(source.read_bytes()).hexdigest()
    hashes[source.name] = before
metadata.write_text(json.dumps(hashes,indent=2)+'\n')
print(hashes)
