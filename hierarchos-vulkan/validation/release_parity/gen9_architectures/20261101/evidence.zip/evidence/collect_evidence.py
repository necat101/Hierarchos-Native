from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
work = root/'target/gen9-phase3'
out = root/'hierarchos-vulkan/validation/release_parity/gen9_architectures/20261101'
out.mkdir(parents=True,exist_ok=False)
def read(name): return json.loads((work/name).read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
forward = read('candidate-forward/qualification.json')
generation = read('candidate-generation/qualification.json')
regressions = read('regressions-final.json')
models = read('regressions.json')['records'][-1]
benchmark = read('benchmark/benchmark.json')
assert forward['pass'] and len(forward['records']) == 166
assert generation['pass'] and len(generation['records']) == 72
assert regressions['pass'] and models['pass'] and models['passed']==53
assert benchmark['pass']
workspace = (work/'workspace-check.log').read_text()
assert 'workspace check passed: 4 crates, 65 binaries' in workspace
assert 'Ran 14 tests' in (work/'harness-tests-final.log').read_text()
assert (work/'harness-tests-final.log').read_text().rstrip().endswith('OK')
previous_path = root/'hierarchos-vulkan/validation/release_parity/deepseek_v41/gen9-20261101/qualification.json'
previous = json.loads(previous_path.read_text())
unchanged = {name: sha for name,sha in previous['implementation_sha256'].items()}
assert all(digest(root/name)==sha for name,sha in unchanged.items())
baseline = read('baseline-run/qualification.json')
manifest = read('cpu-fixtures-reproduced/manifest.json')
handoff = json.loads((root/'HANDOFF-MANIFEST.json').read_text())
original = {name:record['sha256'] for name,record in handoff.items()
            if name.startswith('hierarchos-vulkan/validation/fixtures/deepseek_v41')}
assert len(original)==68 and all(digest(root/name)==sha for name,sha in original.items())
sources = [Path(name) for name in [
    '.github/workflows/workspace-check.yml',
    'VALIDATION_STATUS.md','hierarchos-vulkan/validation/GEN9_ARCHITECTURES_RECEIPT.md',
    'hierarchos-vulkan/validation/DEEPSEEK_V41_GEN9_RECEIPT.md',
    'Cargo.toml','Cargo.lock','hierarchos-vulkan/Cargo.toml','hierarchos-vulkan/Cargo.lock',
    'hierarchos-vulkan/src/transformer.rs','hierarchos-vulkan/src/transformer/peft_state.rs',
    'hierarchos-vulkan/src/transformer/parameter_streaming_tests.rs','hierarchos-vulkan/src/vendor.rs',
    'hierarchos-vulkan/src/bin/transformer_logits.rs','hierarchos-vulkan/src/bin/transformer_generation_parity.rs',
    'hierarchos-vulkan/src/bin/parameter_streaming_bench.rs',
    'hierarchos-vulkan/validation/qualify_gen9_architectures.py',
    'hierarchos-vulkan/validation/qualify_gen9_generation.py',
    'hierarchos-vulkan/validation/benchmark_gen9_architectures.py',
    'hierarchos-vulkan/validation/test_gen9_architectures.py',
    'hierarchos-vulkan/validation/verify_qwen35_generation.py',
    'hierarchos-vulkan/validation/verify_qwen4_exp_generation.py'] if (root/name).is_file()]
source_hashes = {p.as_posix():digest(root/p) for p in sources}
shader_hashes = {p.relative_to(root).as_posix():digest(p)
    for p in sorted((root/'hierarchos-vulkan/shaders').rglob('*.spv'))}
qualification = {
    'schema':1,'status':'recorded_gen9_inference_gates_passed',
    'utc':datetime.now(timezone.utc).isoformat(),
    'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'device':{'cpu':'Intel Core i5-6200U','gpu':'Intel HD Graphics 520',
              'vendor_id':'8086','device_id':'1916','driver':'31.0.101.2115'},
    'gate':{'absolute_limit':2e-7,'rtol':0,'comparison':'strict_less_than',
            'cpu_reference':'independent local Transformers on AVX2',
            'storage_comparison':'every FP32 word, including padded query rows'},
    'forward':{'profiles':43,'native_architectures':forward['native_architectures'],
        'cases':83,'runs':166,'passed':166,
        'compared_logits':sum(r['values'] for r in forward['records']),
        'excluded_cpu_padding_logits':sum(r['excluded_values'] for r in forward['records']),
        'max_abs':max(r['max_abs'] for r in forward['records']),
        'storage_word_differences':sum(r.get('resident_word_differences',0) for r in forward['records']),
        'verified_optimized_dispatch_runs':sum(r.get('optimized_dispatch_verified',False) for r in forward['records']),
        'source_first_profiles':sorted({r['family'] for r in forward['records'] if r['source_first_parameters']})},
    'generation':{'profiles':18,'steps':4,'runs':72,'passed':72,
        'cache_policy':'cache-on/off requests; native support predicate retained',
        'full_prefix_fallback_profiles':['smollm3'],
        'compared_logits':sum(s['values'] for r in generation['records'] for s in r['steps']),
        'max_abs':max(r['max_abs'] for r in generation['records']),
        'storage_word_differences':sum(r.get('resident_word_differences',0) for r in generation['records'])},
    'regressions':{'native':regressions,'v41_model':models,
        'v41_model_binary_sha256':read('regressions.json')['binary_sha256'],'python_negative_controls':14},
    'rdna_handoff_profiles':{'scope':'inference profiles from the earlier 32-profile RDNA matrix; not all 32 CPU PEFT training gates',
        'profiles':manifest['rdna_verified_profiles'],'qualified':forward['rdna_profile_matrix_qualified']},
    'baseline':{'runs':166,'passed':sum(r['pass'] for r in baseline['records']),
        'failures':[{'family':r['family'],'case':r['case'],'mode':r['mode'],
                     'max_abs':r.get('max_abs'),'error':r.get('error')} for r in baseline['records'] if not r['pass']]},
    'oracle':manifest['oracle'],'cpu_reproduction':read('cpu-reproduction.json'),
    'original_frozen_v41_files':original,
    'v41_previous_qualification':{'path':previous_path.relative_to(root).as_posix(),
        'sha256':digest(previous_path),'unchanged_implementation_files':len(unchanged),
        'previous_gate_tests':previous['gate']['passed_tests']},
    'binaries':read('candidate-bin/binaries.json'),'source_sha256':source_hashes,
    'workspace':{'crates':4,'binaries':65,'pass':True,'all_targets':False},
    'shader_sha256':shader_hashes,'benchmark':benchmark['summary'],
    'full_registry_qualified':False,
    'unmeasured_registry_architectures':forward['unmeasured_registry_architectures'],
    'limits':['Retained small and width-control checkpoints; not production model capacity or throughput.',
        'SmolLM3 cache-enabled requests use the existing full-prefix fallback; no native KV-cache certificate for it.',
        'CPU padding comparisons follow the existing observable-query-row contract; storage compares all words.',
        'Kimi-K3 CPU primitive oracle covers dense unpadded inference, not padding or cached generation.',
        'Source-first loading is qualified only for the seven recorded profiles; other body conversion follows loading.',
        'Specialized packed parameter operators remain outside ordinary-linear streaming.',
        'Native PEFT identity regressions do not extend the independent 32-profile CPU PEFT training certificate.',
        'Performance is an observation on this target; this phase changes no shader arithmetic.']}

files = {}
for folder in ['cpu-fixtures','cpu-fixtures-reproduced','cpu-generation-complete',
    'baseline-run','candidate-focused-v2','candidate-forward','candidate-generation',
    'baseline-generation','benchmark']:
    for p in sorted((work/folder).rglob('*')):
        if p.is_file(): files['evidence/'+p.relative_to(work).as_posix()]=p
names = ['build-baseline.log','build-candidate.log','build-tests-final.log','build-tests-corrected.log',
    'prepare.log','prepare-reproduced.log','prepare-generation-complete.log',
    'baseline-run.log','baseline-generation.log','candidate-focused-v2.log',
    'candidate-forward.log','candidate-generation.log','regressions-final.log',
    'regressions-final.json','regression-final-0.log','regression-final-1.log',
    'regression-final-2.log','regression-3.log','harness-tests-final.log',
    'original-fixtures.log','cpu-reproduction.json','workspace-check.log','benchmark.log',
    'collect_evidence.py','save_baseline.py','freeze_candidate.py',
    'baseline_generation.py','run_final_regressions.py']
for name in names:
    path = work/name
    assert path.is_file(), name
    files['evidence/'+name]=path
for folder in ['candidate-bin','baseline-bin']:
    files['evidence/'+folder+'/binaries.json']=work/folder/'binaries.json'
for p in sources: files['source/'+p.as_posix()]=root/p
archive = out/'evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in files.items(): z.write(path,name)
    z.writestr('evidence-file-sha256.json',json.dumps({name:digest(path) for name,path in files.items()},indent=2)+'\n')
qualification['evidence']={'file':archive.name,'bytes':archive.stat().st_size,
                           'sha256':digest(archive),'files':len(files)}
(out/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
print(json.dumps({'receipt':str(out),'evidence':qualification['evidence']},indent=2))
