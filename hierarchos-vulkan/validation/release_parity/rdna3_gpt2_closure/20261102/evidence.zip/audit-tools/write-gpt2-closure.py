"""Freeze the RDNA3 GPT-2 closure without rewriting any earlier receipt."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'hierarchos-vulkan/validation'))
from qualify_gen9_architectures import digest
from summarize_deepseek_v41_final_push import logits, summary

work = ROOT / 'target/gpt2-parity-closure'
gate = work / 'full-gate'
reference = ROOT / 'target/rdna-post-gen9-reference/cpu'
fixture = ROOT / 'hierarchos-vulkan/validation/fixtures/gpt2_rdna3_parity'
out = ROOT / 'hierarchos-vulkan/validation/release_parity/rdna3_gpt2_closure/20261102'
base = subprocess.check_output(['git', 'rev-parse', '3059669'], cwd=ROOT, text=True).strip()

def load(path):
    return json.loads(path.read_text())

def binding(path):
    return {'sha256': digest(path), 'bytes': path.stat().st_size}

run = load(gate / 'qualification.json')
forward = load(gate / 'forward/qualification.json')
generation = load(gate / 'generation/qualification.json')
assert run['pass'] and all(run['scopes'].values())
assert all(row['pass'] and row['exit'] == 0 for row in run['runs'])
assert forward['pass'] and len(forward['records']) == 166
assert generation['pass'] and len(generation['records']) == 72
assert all(row['pass'] and row['max_abs'] < 2e-7 for row in forward['records'] + generation['records'])
assert not any(row.get('resident_word_differences', 0) for row in forward['records'] + generation['records'])
assert all((row['vendor_id'], row['device_id']) == (0x1002, 0x15bf)
           for row in forward['records'] + generation['records'])
assert sum(row.get('passed_tests', 0) for row in run['runs']) == 269

tests = [{k: row[k] for k in ('name', 'passed_tests', 'exit')}
         for row in run['runs'] if 'passed_tests' in row]
for name, expected in [('gpt2-tests-final', 50), ('cli-tests', 41)]:
    text = (work / (name + '.log')).read_text()
    assert f'test result: ok. {expected} passed; 0 failed;' in text, name
    tests.append({'name': name, 'passed_tests': expected, 'exit': 0})
for name, expected, path in [
        ('harness-negative-controls', 16, gate / 'harness-negative-controls.log'),
        ('fixture-negative-controls', 14, work / 'fixture-negative-controls.log'),
        ('runner-negative-controls', 7, work / 'runner-negative-controls.log'),
        ('handoff-negative-controls', 5, work / 'handoff-negative-controls.log')]:
    text = path.read_text()
    assert re.search(rf'Ran {expected} tests? in ', text) and text.rstrip().endswith('OK'), name
    tests.append({'name': name, 'passed_tests': expected, 'exit': 0})
assert 'Finished `dev` profile' in (work / 'workspace-check.log').read_text()
assert 'Finished `test` profile' in (work / 'cli-tests.log').read_text()

shader = load(work / 'shader-provenance.json')
assert shader['pass'] and shader['status_counts'] == {'identical': 573}
assert '431 shader push blocks, 108 host structs' in (work / 'push-layouts.log').read_text()
old_artifacts = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', base,
    '--', 'hierarchos-vulkan/shaders'], cwd=ROOT, text=True).splitlines()
artifact_hashes = {}
for name in old_artifacts:
    if not name.endswith('.spv'):
        continue
    old = subprocess.check_output(['git', 'show', base + ':' + name], cwd=ROOT)
    assert old == (ROOT / name).read_bytes(), name
    artifact_hashes[name] = hashlib.sha256(old).hexdigest()
assert len(artifact_hashes) == 585

original = load(ROOT / 'HANDOFF-MANIFEST.json')
frozen = {name: value for name, value in original.items()
          if name.startswith('hierarchos-vulkan/validation/fixtures/')}
for name, expected in frozen.items():
    assert binding(ROOT / name) == expected, name
assert len(frozen) == 68

# Bind the compact permanent regression fixture to the original CPU archive.
retained = load(fixture / 'fixture.json')
assert retained['comparison'] == 'strict_less_than' and retained['absolute_limit'] == 2e-7 and retained['rtol'] == 0
assert retained['manifest_sha256'] == digest(reference / 'forward/manifest.json')
for case in retained['cases']:
    old = reference / 'forward/gpt2_wide' / case['name']
    cpu = load(old / 'cpu.json')
    inputs = load(old / 'input.json')
    assert case['logits_bits'] == cpu['bits']
    for key in ('input_ids', 'attention_mask', 'batch_size', 'seq_len'):
        assert case[key] == inputs[key], key
    visible = [bool(v) for v in inputs['attention_mask'] for _ in range(320)]
    assert case['visible'] == visible == cpu['visible']
    for name, expected in retained['files'].items():
        assert digest(fixture / name) == expected == digest(old / 'model' / name)

# Every non-GPT-2 output remains identical to the completed post-Gen9 audit.
prior = ROOT / 'target/rdna-post-gen9-attempt1'
identity = {'forward': {'reports': 0, 'words': 0}, 'generation': {'reports': 0, 'words': 0}}
for sub in identity:
    for path in sorted((prior / sub).glob('*.json')):
        if path.name == 'qualification.json' or 'gpt2' in path.name:
            continue
        candidate = gate / sub / path.name
        if not candidate.exists():
            continue
        a, b = load(path), load(candidate)
        # Forward probes store one vector; generation probes store per-step vectors.
        def vectors(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key == 'logits_bits':
                        yield child
                    else:
                        yield from vectors(child)
            elif isinstance(value, list):
                for child in value:
                    yield from vectors(child)
        av, bv = list(vectors(a)), list(vectors(b))
        assert av and av == bv, path
        identity[sub]['reports'] += 1
        def count_words(value):
            return sum(map(count_words, value)) if isinstance(value, list) else 1
        identity[sub]['words'] += sum(map(count_words, av))
assert all(row['reports'] > 0 and row['words'] > 0 for row in identity.values())

numeric = {name: summary(logits(gate / (name + '.log'))) for name in
           ['v41', 'package-default', 'joint-resident', 'joint-streamed', 'peft-trajectory']}
assert numeric['v41']['values'] == 201714
assert sum(v['values'] for k, v in numeric.items() if k != 'v41') == 11184
assert all(v['max_abs'] == 0 for k, v in numeric.items() if k != 'v41')
peft = {mode: load(work / ('peft-' + mode + '-report.json')) for mode in ['resident', 'streaming']}
for mode, result in peft.items():
    assert result['pass'] and result['parameter_streaming'] == (mode == 'streaming')
    assert result['comparison'] == 'strict_less_than' and result['rtol'] == 0
    for key, value in result.items():
        if key.endswith('_max_abs'):
            assert value < 2e-7, (mode, key)
    assert all(value < 2e-7 for value in result['lifecycle'].values())

sources = {}
for name in subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard',
        '--', 'hierarchos-vulkan/src', 'hierarchos-vulkan/shaders', 'hierarchos-native-cli/src',
        'hierarchos-inference/src', 'hierarchos-gui/src'], cwd=ROOT, text=True).splitlines():
    sources[name] = digest(ROOT / name)
sources['hierarchos-vulkan/validation/training_shader_manifest.json'] = digest(
    ROOT / 'hierarchos-vulkan/validation/training_shader_manifest.json')
binaries = {}
for label in ['release-build', 'unit-build']:
    for line in (gate / (label + '.log')).read_text().splitlines():
        if not line.startswith('{'):
            continue
        row = json.loads(line)
        if row.get('reason') == 'compiler-artifact' and row.get('executable'):
            path = Path(row['executable'])
            name = row['target']['name'] + ('-tests' if row['profile'].get('test') else '')
            binaries[name] = {'path': path.relative_to(ROOT).as_posix(), **binding(path)}
for name in ['hierarchos-vulkan-transformer-logits', 'transformer_parity', 'peft_checkpoint']:
    path = ROOT / 'hierarchos-vulkan/target/debug' / (name + '.exe')
    binaries[name + '-peft-debug'] = {'path': path.relative_to(ROOT).as_posix(), **binding(path)}

payloads = {f'full-gate/{path.relative_to(gate).as_posix()}': path
            for path in sorted(gate.rglob('*')) if path.is_file()}
for name in ['gpt2-tests-final.log', 'cli-tests.log', 'workspace-check.log',
             'fixture-negative-controls.log', 'runner-negative-controls.log', 'handoff-negative-controls.log',
             'shader-provenance.json', 'shader-provenance.log', 'push-layouts.log',
             'gen9-preservation.json', 'peft-resident-report.json', 'peft-streaming-report.json',
             'peft-resident.log', 'peft-streaming.log', 'peft-build.log']:
    payloads['checks/' + name] = work / name
for path in sorted(fixture.iterdir()):
    if path.is_file():
        payloads['retained-gpt2-fixture/' + path.name] = path
payloads['audit-tools/write-gpt2-closure.py'] = Path(__file__).resolve()
for name in ['run_rdna3_final_regression.py', 'test_rdna3_final_regression.py',
             'qualify_gen9_architectures.py', 'qualify_gen9_generation.py',
             'verify_peft_lora_strict.py']:
    path = ROOT / 'hierarchos-vulkan/validation' / name
    payloads['audit-tools/' + name] = path
assert all(path.is_file() for path in payloads.values())
payload_manifest = {name: binding(path) for name, path in payloads.items()}
out.mkdir(parents=True, exist_ok=False)
with zipfile.ZipFile(out / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in payloads.items():
        item = zipfile.ZipInfo(name, (2026, 11, 2, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(item, path.read_bytes())
    archive.writestr('EVIDENCE-MANIFEST.json', json.dumps(payload_manifest, indent=2) + '\n')
with zipfile.ZipFile(out / 'evidence.zip') as archive:
    assert archive.testzip() is None
    for name, expected in payload_manifest.items():
        raw = archive.read(name)
        assert len(raw) == expected['bytes'] and hashlib.sha256(raw).hexdigest() == expected['sha256'], name

report = {
    'schema': 1, 'pass': True, 'status': 'rdna3_expanded_matrix_and_peft_pass',
    'date': '2026-11-02', 'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'base_revision': base, 'runtime_binding': 'sources_sha256',
    'device': {'name': 'AMD Radeon Graphics', 'cpu': 'AMD Ryzen Z1 Extreme',
               'vendor_id': 0x1002, 'device_id': 0x15bf, 'driver': '32.0.31007.6002'},
    'gate': {'absolute_limit': 2e-7, 'rtol': 0, 'comparison': 'strict_less_than'},
    'scopes': run['scopes'], 'tests': tests, 'v41_numeric': numeric,
    'forward': {'runs': 166, 'passed': 166, 'profiles': 43, 'native_architecture_identifiers': 26,
                'max_abs': max(row['max_abs'] for row in forward['records']),
                'resident_streaming_word_differences': 0,
                'gpt2_wide': [row for row in forward['records'] if row['family'] == 'gpt2_wide']},
    'generation': {'requests': 72, 'passed': 72,
                   'max_abs': max(row['max_abs'] for row in generation['records']),
                   'resident_streaming_word_differences': 0},
    'gpt2_cpu_peft': peft, 'unchanged_non_gpt2_outputs': identity,
    'gen9_preservation': {'physical_rerun': False, 'pre_existing_artifacts': 585,
        'changed_artifacts': [], 'pre_existing_sha256': artifact_hashes,
        'selection_test': 'gpt2_cpu_math_preserves_gen9_and_other_architecture_routes',
        'scope': 'Intel keeps original pipelines; disabled shared-source variants rebuild byte-identically'},
    'frozen_original_files_checked': len(frozen), 'frozen_original_files_unchanged': True,
    'retained_fixture': {path.name: binding(path) for path in fixture.iterdir() if path.is_file()},
    'shader_rebuilds': shader['status_counts'], 'push_blocks': 431, 'host_push_structs': 108,
    'workspace': {'all_targets': True, 'crates': 4, 'binaries': 65},
    'binaries': binaries, 'sources_sha256': sources,
    'reference_manifests_sha256': run['reference_manifests'],
    'evidence': {'path': 'evidence.zip', **binding(out / 'evidence.zip'), 'files': len(payloads) + 1},
    'limits': ['Physical AMD only; Gen9 artifacts and routing preserved, no new physical Intel run',
        'Scaled checkpoints, not production weights, CUDA or production throughput',
        '120 registry identifiers and all-profile CPU PEFT training remain outside this matrix',
        'Default V4.1 suite ignores 25 explicit or resource-heavy tests; four explicit gates run separately',
        'Native test filters overlap; do not sum the counts as unique tests',
        'SmolLM3 cache requests use its existing full-prefix fallback',
        'CPU forward comparisons exclude existing padded query rows; storage identity includes all rows',
        'Historical toolchain provenance gaps remain recorded in V41_FIXTURE_PROVENANCE.md']}
(out / 'qualification.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
assert load(out / 'qualification.json')['pass']
print(json.dumps({key: report[key] for key in ['evidence', 'forward', 'generation',
    'v41_numeric', 'unchanged_non_gpt2_outputs']}, indent=2))
