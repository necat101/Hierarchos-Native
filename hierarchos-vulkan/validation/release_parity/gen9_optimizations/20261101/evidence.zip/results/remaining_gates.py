from pathlib import Path
import json
import re
import subprocess

work=Path('target/gen9-phase4')
unit=work/'candidate-unit-tests.exe'
cases=[('final-native-cache','generation_kv_cache_matches_full_prefix',False),
       ('final-qwen-next-backward','qwen3_next_gated_delta_end_to_end_backward_matches_finite_difference',False),
       ('final-vulkan','vulkan::tests',False),
       ('package-default','deepseek_v41_default_package_scalable_release_strict_all_logits',True),
       ('joint-resident','deepseek_v41_joint_depth_and_384_expert_strict_all_logits',True),
       ('joint-streamed','deepseek_v41_streamed_vocabulary_joint_strict_all_logits',True),
       ('peft-trajectory','deepseek_v41_production_uninterrupted_training_logit_trajectory',True)]
records=[]
for label,name,ignored in cases:
    command=[str(unit),name,'--nocapture','--test-threads=1']+(['--ignored'] if ignored else [])
    print('RUN',label,flush=True)
    with (work/(label+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    content=(work/(label+'.log')).read_text()
    match=re.search(r'test result: ok\. (\d+) passed; 0 failed;',content)
    record={'name':label,'command':command,'exit':result.returncode,'passed':int(match[1]) if match else 0}
    records.append(record)
    (work/'remaining-gates.json').write_text(json.dumps(records,indent=2)+'\n')
    if result.returncode or not record['passed']: raise RuntimeError(record)
    print('PASS',label,record['passed'],flush=True)
