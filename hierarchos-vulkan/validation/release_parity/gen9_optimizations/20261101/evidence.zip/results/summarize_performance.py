import collections
import json
from pathlib import Path
import re
import statistics
import sys

work=Path('target/gen9-phase4')
sys.path.insert(0,str(Path('hierarchos-vulkan/validation').resolve()))
from rank_kernel_profile import parse
result={}
for family in ['qwen4_exp_mixed_ple','dbrx']:
    result[family]={}
    for mode in ['resident','streaming']:
        result[family][mode]={}
        for arm in ['baseline','candidate']:
            name=f'profile-{family}-{mode}.log' if arm=='baseline' else f'profile-candidate-{family}-{mode}.log'
            submissions=parse(work/name)
            total=sum(s['gpu_ms'] for s in submissions)
            shaders=collections.defaultdict(lambda:[0,0.0])
            for submission in submissions:
                for shader,category,count,ms,samples in submission['shaders']:
                    shaders[shader][0]+=count
                    shaders[shader][1]+=ms
            result[family][mode][arm]={'gpu_ms':total,'shaders':[
                {'name':name,'dispatches':count,'gpu_ms':ms,'us_each':1000*ms/count,'share_percent':100*ms/total}
                for name,(count,ms) in sorted(shaders.items(),key=lambda item:-item[1][1])]}
for arm in ['baseline','candidate']:
    submissions=parse(work/f'v41-benchmark/{arm}-resident-8-8-profile.log')
    total=sum(s['gpu_ms'] for s in submissions)
    shaders=collections.defaultdict(lambda:[0,0.0])
    for submission in submissions:
        for shader,category,count,ms,samples in submission['shaders']:
            shaders[shader][0]+=count
            shaders[shader][1]+=ms
    result.setdefault('v41',{})[arm]={'gpu_ms':total,'shaders':[
        {'name':name,'dispatches':count,'gpu_ms':ms,'us_each':1000*ms/count,'share_percent':100*ms/total}
        for name,(count,ms) in sorted(shaders.items(),key=lambda item:-item[1][1])]}
result['v41_load']={}
comparison=json.loads((work/'v41-benchmark/comparison.json').read_text())
for mode in ['resident','default']:
    medians={}
    for arm in ['baseline','candidate']:
        times=[float(re.search(r'ms=([0-9.]+)',line)[1])
            for record in comparison['runs'] if record['arm']==arm and record['residency']==mode and '-pair' in record['log']
            for line in record['context'] if line.startswith('v41_probe_load ')]
        medians[arm]=statistics.median(times)
    result['v41_load'][mode]={**medians,'candidate_change_percent':100*(medians['candidate']/medians['baseline']-1)}
(work/'performance-profile.json').write_text(json.dumps(result,indent=2)+'\n')
for family in ['qwen4_exp_mixed_ple','dbrx']:
    for mode in ['resident','streaming']:
        for arm in ['baseline','candidate']:
            p=result[family][mode][arm]
            print(family,mode,arm,'gpu_ms',p['gpu_ms'],'qsa',[s for s in p['shaders'] if 'qsa_mask' in s['name']])
print('LOAD',result['v41_load'])
