import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root=Path.cwd()
work=root/'target/gen9-phase4'
destination=root/'hierarchos-vulkan/validation/release_parity/gen9_optimizations/20261101'
destination.mkdir(parents=True,exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())
forward=load(work/'candidate-forward/qualification.json')
generation=load(work/'candidate-generation/qualification.json')
benchmark=load(work/'warm-benchmark/benchmark.json')
recheck=load(work/'streaming-recheck/benchmark.json')
v41bench=load(work/'v41-benchmark/comparison.json')
audit=load(work/'frozen-audit.json')
shaders=load(work/'shader-provenance.json')
gates=load(work/'remaining-gates.json')
assert forward['pass'] and generation['pass'] and benchmark['pass'] and recheck['pass'] and audit['pass'] and shaders['pass']
assert len(gates)==7 and all(g['exit']==0 and g['passed']>0 for g in gates)
tests=[]
for name in ['v41-strict','offload-tests','payload-identity-tests','final-streaming']:
    content=(work/(name+'.log')).read_text()
    match=re.search(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',content)
    assert match and int(match[1])>0,name
    tests.append({'name':name,'passed':int(match[1]),'ignored':int(match[2])})
tests.extend(gates)
test_names=set()
for test in tests:
    content=(work/(test['name']+'.log')).read_text()
    for name,tail in re.findall(r'^test (\S+) \.\.\.([^\n]*)',content,re.M):
        if not tail.startswith(' ignored'):test_names.add(name)
assert len(test_names)==268
micro={}
for name in ['qsa','hc','silu']:
    text=(work/('idle-'+name+'.log')).read_text()
    report=next(json.loads(line) for line in text.splitlines() if line.startswith('{"cases"'))
    assert all(r['bit_exact'] for r in report['records'])
    micro[name]=report
io=load(work/'idle-io.json')
receipt={'schema':1,'status':'gen9_optimization_gates_passed_rdna3_final_regression_pending',
    'date':'2026-11-01','timezone':'America/Los_Angeles',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'device':{'cpu':'Intel Core i5-6200U','gpu':'Intel HD Graphics 520','vendor_id':'8086',
        'device_id':'1916','driver':'31.0.101.2115'},
    'gate':{'absolute_limit':2e-7,'rtol':0,'comparison':'strict_less_than'},
    'forward':{'runs':len(forward['records']),'profiles':len({r['family'] for r in forward['records']}),
        'architectures':forward['native_architectures'],'worst_cpu_error':max(r['max_abs'] for r in forward['records']),
        'observable_values':sum(r['values'] for r in forward['records']),
        'excluded_padded_query_values':sum(r['excluded_values'] for r in forward['records']),
        'rdna_profile_matrix_qualified':forward['rdna_profile_matrix_qualified'],
        'unmeasured_registry_architectures':forward['unmeasured_registry_architectures']},
    'generation':{'runs':len(generation['records']),'worst_cpu_error':max(r['max_abs'] for r in generation['records']),
        'values':sum(s['values'] for r in generation['records'] for s in r['steps'])},
    'previous_gen9_word_identity':audit['logits'],
    'frozen_reference_manifests':audit['reference_manifests'],
    'original_frozen_file_count':len(audit['original_fixtures']),
    'unchanged_preexisting_shader_count':len(audit['preexisting_shaders']),
    'shader_provenance_status':shaders['status_counts'],'tests':tests,
    'distinct_rust_tests':len(test_names),'rust_test_names':sorted(test_names),
    'paired_warm_latency':benchmark['summary'],'paired_v41_latency':v41bench['timings'],
    'longer_streaming_recheck':recheck['summary'],'llama_streaming_diagnostic':load(work/'llama-diagnostic.json'),
    'performance_profile':load(work/'performance-profile.json'),
    'same_shard_control':load(work/'same-shard-benchmark.json'),
    'standalone_shader_controls':micro,'io_probe':io,
    'binaries':load(work/'candidate-bin/binaries.json'),
    'test_executables':{name:sha(work/name) for name in ['checkpoint-unit-tests.exe','candidate-unit-tests.exe']},
    'limits':['Retained scaled checkpoints; no production throughput claim',
        'Physical RDNA3 rerun is required before push; no new AMD hardware result claimed',
        'SmolLM3 cache requests use the existing full-prefix fallback',
        '120 architecture identifiers remain unmeasured; CPU training parity is not extended to every profile',
        '54 historical V4.1 fixture toolchains remain unverified; 17 have genuine pins'],
    'implementation_sha256':{},'evidence':{}}

files={}
def add(source,label):
    assert label not in files,label
    files[label]=source
for folder in [root/'hierarchos-vulkan/src',root/'hierarchos-vulkan/shaders']:
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix in {'.rs','.comp','.glsl','.spv'}:
            relative=path.relative_to(root).as_posix()
            receipt['implementation_sha256'][relative]=sha(path)
            add(path,'implementation/'+relative)
for path in sorted((root/'hierarchos-vulkan/validation').iterdir()):
    if path.is_file() and path.suffix in {'.py','.rs','.ps1','.json','.md'}:
        add(path,'validation/'+path.name)
# Original V4.1 payloads already belong to the checkout and are hash-bound by
# the historical manifest and frozen audit; avoid duplicating their large data.
add(root/'HANDOFF-MANIFEST.json','frozen-v41/HANDOFF-MANIFEST.json')
for name,label in [('cpu-fixtures-reproduced','forward'),('cpu-fixtures','generation-packages'),
                   ('cpu-generation-complete','generation')]:
    source=root/'target/gen9-phase3'/name
    for path in sorted(source.rglob('*')):
        if path.is_file():add(path,'cpu/'+label+'/'+path.relative_to(source).as_posix())
for folder in ['candidate-forward','candidate-generation','warm-benchmark','v41-benchmark','streaming-recheck']:
    for path in sorted((work/folder).rglob('*')):
        if path.is_file():add(path,'results/'+folder+'/'+path.relative_to(work/folder).as_posix())
for name in ['v41-strict','offload-tests','payload-identity-tests','final-streaming','final-native-cache',
    'final-qwen-next-backward','final-vulkan','package-default','joint-resident','joint-streamed','peft-trajectory',
    'build-release','build-tests-final','workspace-check','push-constants','shader-provenance',
    'fixture-toolchain','harness-tests-final','frozen-audit','idle-qsa','idle-hc','idle-silu']:
    add(work/(name+'.log'),'results/'+name+'.log')
for path in sorted(work.glob('idle-io-*')):
    if path.suffix=='.log':add(path,'results/'+path.name)
for pattern in ['same-shard-*.log','llama-diagnostic-*.log','llama-diagnostic-*.json']:
    for path in sorted(work.glob(pattern)):add(path,'results/'+path.name)
for path in sorted(work.glob('profile-*')):
    if path.suffix in {'.json','.log'}:add(path,'results/'+path.name)
for name in ['shader-provenance.json','frozen-audit.json','remaining-gates.json','idle-io.json',
    'shader-candidates.json','compile_shaders.py','build_probe.py','qualify_candidate.py',
    'remaining_gates.py','benchmark_candidate.py','audit_frozen.py','package_receipt.py','baseline-weight_offload.rs',
    'same-shard-benchmark.json','same-shard-payloads.json','benchmark_repacked.py','llama-diagnostic.json',
    'diagnose_llama_streaming.py','performance-profile.json','summarize_performance.py']:
    add(work/name,'results/'+name)
for name in ['candidate-bin','baseline-bin']:
    add(work/name/'binaries.json','results/'+name+'/binaries.json')
archive=destination/'evidence.zip'
contents={label:{'bytes':source.stat().st_size,'sha256':sha(source)} for label,source in sorted(files.items())}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for label,source in sorted(files.items()):output.write(source,label)
    output.writestr('CONTENTS.json',json.dumps(contents,indent=2)+'\n')
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for label,expected in contents.items():
        data=output.read(label)
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],label
receipt['evidence']={'file':'evidence.zip','bytes':archive.stat().st_size,'sha256':sha(archive),
    'files':len(contents),'all_member_hashes_verified':True}
(destination/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'evidence':receipt['evidence'],'tests':sum(t['passed'] for t in tests)},indent=2))
