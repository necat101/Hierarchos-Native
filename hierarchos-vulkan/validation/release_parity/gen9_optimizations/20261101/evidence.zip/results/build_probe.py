from pathlib import Path
import os
import shutil
import subprocess
import sys
root=Path.cwd()
work=root/'target/gen9-phase4'
out=work/'probe-build'
out.mkdir(exist_ok=True)
registry=max((root/'hierarchos-vulkan/target/release/build').glob('hierarchos-vulkan-*/out/shader_debug_registry.rs'),key=lambda p:p.stat().st_mtime)
shutil.copy2(registry,out/'shader_debug_registry.rs')
baseline=work/'baseline-weight_offload.rs'
if not baseline.exists(): baseline.write_bytes(subprocess.check_output(['git','show','HEAD:hierarchos-vulkan/src/weight_offload.rs']))
deps=root/'hierarchos-vulkan/target/release/deps'
command=['rustc','--edition=2021','-C','opt-level=3','-C','debuginfo=0','-C','lto=thin','-C','codegen-units=1',
         '-L','dependency='+str(deps)]
for native in (Path.home()/'.cargo/registry/src').glob('*/windows_x86_64_msvc-0.52*/lib'):
    command+=['-L','native='+str(native)]
for name in ['anyhow','ash','bytemuck','windows_sys','serde','serde_json','safetensors']:
    candidates=list(deps.glob('lib'+name+'-*.rlib'))
    if name=='windows_sys':
        candidates=[p for p in candidates if 'windows-sys-0.59' in p.with_name(p.name[3:]).with_suffix('.d').read_text(errors='ignore')]
    library=max(candidates,key=lambda p:p.stat().st_mtime)
    command+=['--extern',name+'='+str(library)]
mode=sys.argv[1] if len(sys.argv)>1 else 'candidate'
if mode=='baseline': command+=['--cfg','baseline_io']
command+=[str(root/'hierarchos-vulkan/validation/gen9_optimization_probe.rs'),'-o',str(work/f'probe-{mode}.exe')]
process=subprocess.run(command,env=dict(os.environ,OUT_DIR=str(out)),capture_output=True,text=True)
(work/f'build-probe-{mode}.log').write_text(process.stdout+process.stderr)
if process.returncode: print(process.stdout+process.stderr)
raise SystemExit(process.returncode)
