import hashlib
import json
from pathlib import Path

root=Path.cwd()
work=root/'target/gen9-phase4'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
result={'pass':False,'logits':{},'original_fixtures':{},'preexisting_shaders':{}}
for label in ['candidate-forward','candidate-generation']:
    count=0
    reports=0
    previous=root/'target/gen9-phase3'/label
    for path in (work/label).glob('*.json'):
        if path.name=='qualification.json': continue
        current=json.loads(path.read_text())
        original=json.loads((previous/path.name).read_text())
        actual=current['logits_bits']
        expected=original['logits_bits']
        assert actual==expected,path.name
        count+=sum(len(step) for step in actual) if actual and isinstance(actual[0],list) else len(actual)
        reports+=1
    result['logits'][label]={'reports':reports,'words':count,'differences':0}
manifest=json.loads((root/'HANDOFF-MANIFEST.json').read_text())
for name,expected in manifest.items():
    if name.startswith('hierarchos-vulkan/validation/fixtures/'):
        assert sha(root/name)==expected['sha256'],name
        result['original_fixtures'][name]=expected['sha256']
prior=json.loads((root/'hierarchos-vulkan/validation/release_parity/gen9_architectures/20261101/qualification.json').read_text())
for name,expected in prior['shader_sha256'].items():
    assert sha(root/name)==expected,name
    result['preexisting_shaders'][name]=expected
result['reference_manifests']={name:sha(root/'target/gen9-phase3'/name/'manifest.json')
    for name in ['cpu-fixtures','cpu-fixtures-reproduced','cpu-generation-complete']}
result['pass']=True
(work/'frozen-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({**result,'original_fixtures':len(result['original_fixtures']),
    'preexisting_shaders':len(result['preexisting_shaders'])},indent=2))
