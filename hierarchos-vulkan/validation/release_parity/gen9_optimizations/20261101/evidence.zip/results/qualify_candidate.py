from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root = Path.cwd()
work = root / 'target/gen9-phase4'
bins = work / 'candidate-bin'
bins.mkdir()
metadata = {}
for name in ['hierarchos-vulkan-transformer-logits', 'transformer_generation_parity',
             'parameter_streaming_bench', 'hierarchos-vulkan-deepseek-v41-forward-probe']:
    source = root / 'hierarchos-vulkan/target/release' / (name + '.exe')
    expected = hashlib.sha256(source.read_bytes()).hexdigest()
    destination = bins / source.name
    shutil.copy2(source, destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == expected
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    metadata[name] = {'sha256': expected, 'path': str(destination)}
(bins / 'binaries.json').write_text(json.dumps(metadata, indent=2) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    with (work / (label + '.log')).open('w') as log:
        result = subprocess.run([str(item) for item in command], stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{label} failed: {result.returncode}')
    print('PASS', label, flush=True)

unit = work / 'candidate-unit-tests.exe'
run('final-streaming', [unit, 'parameter_streaming', '--nocapture', '--test-threads=1'])
run('final-kv-cache', [unit, 'kv_cache_tests::', '--nocapture', '--test-threads=1'])
run('candidate-forward', [sys.executable, root / 'hierarchos-vulkan/validation/qualify_gen9_architectures.py',
    'run', '--fixtures', root / 'target/gen9-phase3/cpu-fixtures-reproduced',
    '--binary', bins / 'hierarchos-vulkan-transformer-logits.exe', '--output', work / 'candidate-forward'])
run('candidate-generation', [sys.executable, root / 'hierarchos-vulkan/validation/qualify_gen9_generation.py',
    'run', '--fixtures', root / 'target/gen9-phase3/cpu-generation-complete',
    '--packages', root / 'target/gen9-phase3/cpu-fixtures',
    '--binary', bins / 'transformer_generation_parity.exe', '--output', work / 'candidate-generation'])
