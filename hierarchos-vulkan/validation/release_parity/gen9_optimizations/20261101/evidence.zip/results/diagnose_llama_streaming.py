from pathlib import Path
import json
import os
import statistics
import subprocess

work=Path('target/gen9-phase4')
fixtures=Path('target/gen9-phase3/cpu-fixtures-reproduced')
case=next(c for c in json.loads((fixtures/'manifest.json').read_text())['cases']
          if c['family']=='llama_wide' and c['case']=='unmasked')
records=[]
words=None
for pair in range(5):
    arms=['baseline','candidate','candidate-unfused']
    if pair%2:arms.reverse()
    for arm in arms:
        version='baseline' if arm=='baseline' else 'candidate'
        command=[str((work/f'{version}-bin/parameter_streaming_bench.exe').resolve()),
            str((fixtures/case['package']).resolve()),str((fixtures/case['input']).resolve()),
            '5','31','inference','streaming']
        env=dict(os.environ)
        if arm=='candidate-unfused':env['HIERARCHOS_VULKAN_GEN9_FUSED_SILU']='0'
        result=subprocess.run(command,env=env,capture_output=True,text=True)
        label=f'llama-diagnostic-{pair}-{arm}'
        (work/(label+'.log')).write_text(result.stderr)
        assert result.returncode==0,label
        report=json.loads(result.stdout)
        if words is not None:assert report['logits_bits']==words
        words=report['logits_bits']
        (work/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
        records.append({'arm':arm,'pair':pair,'ms':report['median_ms'],'submissions':report['submissions']})
        print('PASS',label,report['median_ms'],flush=True)
summary={arm:statistics.median(r['ms'] for r in records if r['arm']==arm)
    for arm in ['baseline','candidate','candidate-unfused']}
(work/'llama-diagnostic.json').write_text(json.dumps({'records':records,'medians':summary},indent=2)+'\n')
print(summary)
