from pathlib import Path
import hashlib
import json
import shutil
import subprocess
root=Path.cwd()
work=root/'target/gen9-phase4'
old=work/'baseline-shaders'
old.mkdir(exist_ok=True)
new=work/'candidate-shaders'
new.mkdir(exist_ok=True)
shaders=root/'hierarchos-vulkan/shaders'
records=[]
for stem,tool,flags,define in [
    ('transformer_deepseek_v41_hc_split','.tools/glslang-16.6.0/bin/glslang.exe',['-V','--target-env','vulkan1.1'],'HIERARCHOS_GEN9_PARALLEL_HC'),
    ('transformer_qwen4_qsa_mask','.tools/env/Library/bin/glslc.exe',[],'HIERARCHOS_GEN9_PARALLEL_QSA'),
    ('silu_forward','.tools/glslang-16.6.0/bin/glslang.exe',['-V','--target-env','vulkan1.0'],'HIERARCHOS_GEN9_SILU_MUL')]:
    source=shaders/(stem+'.comp')
    baseline=old/(stem+'.spv')
    if not baseline.exists(): shutil.copy2(shaders/baseline.name,baseline)
    rebuilt=new/(stem+'-native.spv')
    command=[str(root/tool),*flags,str(source),'-o',str(rebuilt)]
    process=subprocess.run(command,capture_output=True,text=True)
    assert process.returncode==0,process.stdout+process.stderr
    assert rebuilt.read_bytes()==baseline.read_bytes(),stem+' changed native artifact'
    candidate=new/(stem+'_gen9.spv')
    command=[str(root/tool),*flags,'-D'+define+'=1',str(source),'-o',str(candidate)]
    process=subprocess.run(command,capture_output=True,text=True)
    assert process.returncode==0,process.stdout+process.stderr
    validation=subprocess.run([str(root/'.tools/env/Library/bin/spirv-val.exe'),str(candidate)],capture_output=True,text=True)
    assert validation.returncode==0,validation.stdout+validation.stderr
    records.append({'source':str(source),'native_unchanged':True,'candidate':str(candidate),'sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'command':command})
(work/'shader-candidates.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
