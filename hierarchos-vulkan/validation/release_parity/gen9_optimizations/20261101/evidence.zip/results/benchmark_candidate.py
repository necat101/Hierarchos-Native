from pathlib import Path
import json
import os
import statistics
import subprocess
import sys

root=Path.cwd()
work=root/'target/gen9-phase4'
def run(label,command):
    print('RUN',label,flush=True)
    with (work/(label+'.log')).open('w') as log:
        result=subprocess.run([str(item) for item in command],stdout=log,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError(f'{label}: {result.returncode}')
    print('PASS',label,flush=True)

run('warm-benchmark',[sys.executable,root/'hierarchos-vulkan/validation/benchmark_gen9_architectures.py',
    '--fixtures',root/'target/gen9-phase3/cpu-fixtures-reproduced',
    '--baseline',work/'baseline-bin/parameter_streaming_bench.exe',
    '--candidate',work/'candidate-bin/parameter_streaming_bench.exe',
    '--baseline-resident','--output',work/'warm-benchmark','--rounds','3',
    '--families','gpt2_wide','llama_wide','qwen3_next','qwen3_5_mixed',
    'qwen4_exp_mixed_ple','minimax_m3','dbrx','gpt_oss'])
run('v41-benchmark',[sys.executable,root/'hierarchos-vulkan/validation/benchmark_deepseek_v41_gen9.py',
    '--baseline',work/'baseline-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe',
    '--candidate',work/'candidate-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe',
    '--output',work/'v41-benchmark','--pairs','3','--steps','2','--profile'])
for command in ['qsa','hc','silu']:
    run('idle-'+command,[work/'probe-candidate.exe',command,work])
records=[]
for pair in range(3):
    for arm in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
        label=f'idle-io-{pair}-{arm}'
        run(label,[work/f'probe-{arm}.exe','io',work])
        content=(work/(label+'.log')).read_text()
        report=next(json.loads(line) for line in content.splitlines() if line.startswith('{"ledger"'))
        records.append({'pair':pair,'arm':arm,'ms':sum(r['ms'] for r in report['records']),
                        'ledger':report['ledger']})
medians={arm:statistics.median(r['ms'] for r in records if r['arm']==arm)
         for arm in ['baseline','candidate']}
(work/'idle-io.json').write_text(json.dumps({'records':records,'medians':medians,
    'speedup':medians['baseline']/medians['candidate']},indent=2)+'\n')

manifest=json.loads((root/'target/gen9-phase3/cpu-fixtures-reproduced/manifest.json').read_text())
fixtures=root/'target/gen9-phase3/cpu-fixtures-reproduced'
for family in ['qwen4_exp_mixed_ple','dbrx']:
    case=next(c for c in manifest['cases'] if c['family']==family and c['case']=='unmasked')
    for mode in ['resident','streaming']:
        command=[str(work/'candidate-bin/parameter_streaming_bench.exe'),str(fixtures/case['package']),
            str(fixtures/case['input']),'1','2','inference',mode]
        result=subprocess.run(command,capture_output=True,text=True,env=dict(os.environ,
            HIERARCHOS_VULKAN_PROFILE_KERNELS='1',HIERARCHOS_VULKAN_PROFILE_SAMPLE_STRIDE='1',
            HIERARCHOS_VULKAN_PROFILE_TOP_SHADERS='4096'))
        (work/f'profile-candidate-{family}-{mode}.log').write_text(result.stderr)
        (work/f'profile-candidate-{family}-{mode}.json').write_text(result.stdout)
        if result.returncode: raise RuntimeError(command)
        print('PASS PROFILE',family,mode,flush=True)
