"""Exercise same-shard expert batches using unchanged tensor payload bytes."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import statistics
import struct
import subprocess

work=Path('target/gen9-phase4')
original=Path('hierarchos-vulkan/validation/fixtures/deepseek_v41_joint_4141111')
model=work/'same-shard-checkpoint'
model.mkdir()
index=json.loads((original/'model.safetensors.index.json').read_text())
headers={}
for filename in set(index['weight_map'].values()):
    with (original/filename).open('rb') as stream:
        size=struct.unpack('<Q',stream.read(8))[0]
        headers[filename]=(8+size,json.loads(stream.read(size)))
payloads=[]
header={}
cursor=0
hashes={}
for name,filename in sorted(index['weight_map'].items()):
    base,entries=headers[filename]
    info=entries[name]
    start,end=info['data_offsets']
    with (original/filename).open('rb') as stream:
        stream.seek(base+start)
        data=stream.read(end-start)
    assert len(data)==end-start
    hashes[name]={'dtype':info['dtype'],'shape':info['shape'],
        'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    header[name]={**info,'data_offsets':[cursor,cursor+len(data)]}
    cursor+=len(data)
    payloads.append(data)
encoded=json.dumps(header,separators=(',',':')).encode()
encoded+=b' '*((-len(encoded))%64)
with (model/'weights.safetensors').open('xb') as stream:
    stream.write(struct.pack('<Q',len(encoded)))
    stream.write(encoded)
    for data in payloads:stream.write(data)
del payloads
index['weight_map']={name:'weights.safetensors' for name in index['weight_map']}
(model/'model.safetensors.index.json').write_text(json.dumps(index,indent=2)+'\n')
for name in ['config.json','engram_tokens.json']:shutil.copyfile(original/name,model/name)
with (model/'weights.safetensors').open('rb') as stream:
    for name,expected in hashes.items():
        start,end=header[name]['data_offsets']
        stream.seek(8+len(encoded)+start)
        assert hashlib.sha256(stream.read(end-start)).hexdigest()==expected['sha256']
(work/'same-shard-payloads.json').write_text(json.dumps(hashes,indent=2)+'\n')
records=[]
for mode,decode,digest in [('resident',8,'90e096ebc5bf0659'),('default',4,'2d2f8e2d5914a0d2')]:
    for pair in range(3):
        for arm in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
            command=[str((work/f'{arm}-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe').resolve()),
                '--model',str(model.resolve()),'--residency',mode,'--prefill','8','--decode',str(decode),
                '--steps','1','--warmup','0']
            completed=subprocess.run(command,capture_output=True,text=True)
            content=completed.stdout+completed.stderr
            log=work/f'same-shard-{mode}-{pair}-{arm}.log'
            log.write_text(content)
            assert completed.returncode==0,log
            actual=re.findall(r'v41_probe_logits .*?digest=([0-9a-f]+)',content)
            assert actual and all(item==digest for item in actual),(log,actual)
            load=float(re.search(r'v41_probe_load ms=([0-9.]+)',content)[1])
            io=json.loads(next(line.split('json=',1)[1] for line in content.splitlines()
                if line.startswith('v41_probe_io phase=complete ')))
            records.append({'arm':arm,'mode':mode,'pair':pair,'load_ms':load,'io':io,'digest':digest,'log':log.name})
            print('PASS',mode,pair,arm,load,flush=True)
result={'pass':True,'tensor_payloads':len(hashes),'payload_bytes':cursor,'records':records,
        'scope':'Exact tensor-byte repack; original multi-shard checkpoint is unchanged','summary':{}}
for mode in ['resident','default']:
    medians={arm:statistics.median(r['load_ms'] for r in records if r['arm']==arm and r['mode']==mode)
        for arm in ['baseline','candidate']}
    result['summary'][mode]={**medians,'load_reduction_percent':100*(1-medians['candidate']/medians['baseline'])}
(work/'same-shard-benchmark.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary'],indent=2))
