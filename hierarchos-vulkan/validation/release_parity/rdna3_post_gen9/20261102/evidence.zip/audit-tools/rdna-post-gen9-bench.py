"""RDNA3 comparison against the preserved, qualified handoff executable."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'hierarchos-vulkan/validation'))
from qualify_gen9_architectures import compare_logits, digest, words, write_json

fixtures = ROOT / 'target/rdna-post-gen9-reference/cpu/forward'
out = ROOT / 'target/rdna-post-gen9-performance'
out.mkdir(exist_ok=False)
executables = {
    'baseline': ROOT / 'target/rdna-post-gen9-baseline/streaming-handoff.exe',
    'candidate': ROOT / 'hierarchos-vulkan/target/release/parameter_streaming_bench.exe',
}
manifest = json.loads((fixtures / 'manifest.json').read_text())
cases = {c['family']: c for c in manifest['cases'] if c['case'] == 'unmasked'}
result = dict(pass_=False, target='AMD 1002:15bf', records=[], summary={},
    binaries={k: {'sha256': digest(v), 'path': str(v)} for k, v in executables.items()},
    limits=['Scaled checkpoints; timing observations, not production throughput',
            'Legacy baseline supports streaming only and reports adapter name, not PCI identity'])
for family in ['gpt2_wide', 'llama_wide', 'qwen3_next', 'qwen3_5_mixed',
               'qwen4_exp_mixed_ple', 'minimax_m3', 'gpt_oss', 'mixtral']:
    case = cases[family]
    for name, expected in case['files'].items():
        assert digest(fixtures / name) == expected
    cpu = json.loads((fixtures / case['cpu']).read_text())
    reference = None
    for rnd in range(3):
        arms = [('baseline', 'streaming'), ('candidate', 'streaming'), ('candidate', 'resident')]
        if rnd % 2:
            arms.reverse()
        for version, mode in arms:
            cmd = [str(executables[version]), str(fixtures / case['package']),
                   str(fixtures / case['input']), '5', '31', 'inference']
            if version == 'candidate':
                cmd.append(mode)
            label = f'{family}-{rnd}-{version}-{mode}'
            env = {k: v for k, v in os.environ.items() if not k.startswith('HIERARCHOS_VULKAN_')}
            run = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=300)
            (out / (label + '.log')).write_text(run.stderr, encoding='utf-8')
            assert run.returncode == 0, (label, run.returncode)
            report = json.loads(run.stdout)
            write_json(out / (label + '.json'), report)
            assert report['device'] == 'AMD Radeon Graphics', report['device']
            if version == 'candidate':
                assert (report['vendor_id'], report['device_id']) == (0x1002, 0x15bf)
                assert report['residency'] == mode
                assert (report['streamed_linears'] > 0) == (mode == 'streaming')
            actual = report.get('logits_bits', words(report['logits']))
            check = compare_logits(actual, cpu['bits'], cpu['visible'])
            assert check['pass'], (label, check)
            if reference is None:
                reference = actual
            assert actual == reference, f'{label}: baseline/candidate/storage words changed'
            result['records'].append(dict(family=family, round=rnd, version=version,
                mode=mode, median_ms=report['median_ms'], cpu_max_abs=check['max_abs'],
                submissions=report['submissions'], report=label + '.json'))
            print(label, report['median_ms'], flush=True)
            write_json(out / 'comparison.json', result)
    result['summary'][family] = {
        f'{version}_{mode}_ms': statistics.median(r['median_ms'] for r in result['records']
            if (r['family'], r['version'], r['mode']) == (family, version, mode))
        for version, mode in arms}
    s = result['summary'][family]
    s['streaming_latency_change_percent'] = 100 * (s['candidate_streaming_ms'] / s['baseline_streaming_ms'] - 1)
for key, path in executables.items():
    assert digest(path) == result['binaries'][key]['sha256']
result['pass_'] = True
write_json(out / 'comparison.json', result)
print(json.dumps(result['summary'], indent=2))
