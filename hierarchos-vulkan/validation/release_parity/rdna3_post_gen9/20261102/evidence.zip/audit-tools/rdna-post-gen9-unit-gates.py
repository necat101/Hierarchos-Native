import json,subprocess,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'target/rdna-post-gen9-attempt1'
entries=[]
for line in (out/'unit-build.log').read_text().splitlines():
 if line.startswith('{'):
  r=json.loads(line)
  if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile'].get('test'):
   entries.append(r['executable'])
assert len(entries)==1,entries
results=[]
for label,name,ignored in [('v41','deepseek_v41::',False),('vulkan','vulkan::tests',False),
 ('streaming','parameter_streaming',False),('offload','weight_offload::tests',False),
 ('kv-cache','generation_kv_cache_matches_full_prefix',False),
 ('qwen-next-backward','qwen3_next_gated_delta_end_to_end_backward_matches_finite_difference',False),
 ('package-default','deepseek_v41_default_package_scalable_release_strict_all_logits',True),
 ('joint-resident','deepseek_v41_joint_depth_and_384_expert_strict_all_logits',True),
 ('joint-streamed','deepseek_v41_streamed_vocabulary_joint_strict_all_logits',True),
 ('peft-trajectory','deepseek_v41_production_uninterrupted_training_logit_trajectory',True)]:
 cmd=[entries[0],name,'--nocapture','--test-threads=1']+(['--ignored'] if ignored else [])
 print('RUN',label,flush=True)
 with (out/(label+'.log')).open('w',encoding='utf-8') as log:
  r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(label+'.log')).read_text()
 m=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',text)
 result=dict(name=label,exit=r.returncode,passed=int(m[1]) if m else 0,failed=int(m[2]) if m else None)
 results.append(result)
 (out/'native-gates.json').write_text(json.dumps(results,indent=2))
 print(result,flush=True)
raise SystemExit(int(any(r['exit'] or not r['passed'] for r in results)))
