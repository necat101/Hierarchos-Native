import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'hierarchos-vulkan/validation'))
from qualify_gen9_architectures import digest
from summarize_deepseek_v41_final_push import logits, summary

gate=ROOT/'target/rdna-post-gen9-attempt1'
reference=ROOT/'target/rdna-post-gen9-reference/cpu/forward'
out=ROOT/'hierarchos-vulkan/validation/release_parity/rdna3_post_gen9/20261102'
out.mkdir(parents=True,exist_ok=False)
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',
    'hierarchos-vulkan/src','hierarchos-vulkan/shaders','hierarchos-native-cli/src',
    'hierarchos-inference/src','hierarchos-gui/src'],cwd=ROOT,text=True).strip()
forward=json.loads((gate/'forward/qualification.json').read_text())
generation=json.loads((gate/'generation/qualification.json').read_text())
manifest=json.loads((reference/'manifest.json').read_text())
prior=[r for r in forward['records'] if r['family'] in manifest['rdna_verified_profiles']]
failures=[r for r in forward['records'] if not r['pass']]
assert len(forward['records'])==166 and len(prior)==122
assert forward['rdna_profile_matrix_qualified'] and all(r['pass'] for r in prior)
assert {(r['family'],r['case'],r['mode']) for r in failures}=={
    ('gpt2_wide','padded','resident'),('gpt2_wide','padded','streaming')}
assert generation['pass'] and len(generation['records'])==72
assert not any(r.get('resident_word_differences',0) for r in forward['records']+generation['records'])
assert all((r['vendor_id'],r['device_id'])==(0x1002,0x15bf)
           for r in forward['records']+generation['records'])

baseline=json.loads((gate/'gpt2-wide-baseline.json').read_text())
candidate=json.loads((gate/'forward/gpt2_wide-padded-streaming.json').read_text())
baseline_words=baseline.get('logits_bits')
if baseline_words is None:
    from qualify_gen9_architectures import words
    baseline_words=words(baseline['logits'])
assert baseline_words==candidate['logits_bits'] and len(baseline_words)==3840
baseline_hash=digest(ROOT/'target/rdna-post-gen9-baseline/streaming-handoff.exe')
binding=ROOT/'hierarchos-vulkan/validation/release_parity/deepseek_v41/rdna3-submission-batching.json'
assert baseline_hash in binding.read_text()

tests=json.loads((gate/'native-gates.json').read_text())
assert sum(row['passed'] for row in tests)==269 and all(row['exit']==0 for row in tests)
for label,expected in [('gpt2-native-regression',48),('cli-tests',41),
                       ('harness-negative-controls',16),('fixture-negative-controls',14),
                       ('handoff-negative-controls',5),('runner-negative-controls',7)]:
    content=(gate/(label+'.log')).read_text()
    if 'negative-controls' in label:
        assert re.search(rf'Ran {expected} tests? in ',content) and content.rstrip().endswith('OK'),label
    else:
        assert f'test result: ok. {expected} passed; 0 failed;' in content,label
    tests.append(dict(name=label,passed=expected,exit=0))
assert 'Finished `dev` profile' in (gate/'workspace-check.log').read_text()
shader=json.loads((gate/'shader-provenance.json').read_text())
assert shader['pass'] and shader['status_counts']=={'identical':569}
assert '429 shader push blocks, 108 host structs' in (gate/'push-layouts.log').read_text()
original=json.loads((ROOT/'HANDOFF-MANIFEST.json').read_text())
frozen={name:value for name,value in original.items()
        if name.startswith('hierarchos-vulkan/validation/fixtures/')}
for name,expected in frozen.items():
    assert digest(ROOT/name)==expected['sha256'] and (ROOT/name).stat().st_size==expected['bytes'],name
numeric={name:summary(logits(gate/(name+'.log')))
         for name in ['v41','package-default','joint-resident','joint-streamed','peft-trajectory']}
assert sum(v['values'] for k,v in numeric.items() if k!='v41')==11184
assert all(v['max_abs']==0 for k,v in numeric.items() if k!='v41')

binaries={}
for log in ['release-build','unit-build']:
    for line in (gate/(log+'.log')).read_text().splitlines():
        if not line.startswith('{'):continue
        r=json.loads(line)
        if r.get('reason')=='compiler-artifact' and r.get('executable'):
            p=Path(r['executable'])
            binaries[r['target']['name']+('-tests' if r['profile'].get('test') else '')]={
                'sha256':digest(p),'path':str(p.relative_to(ROOT))}
sources={}
for name in subprocess.check_output(['git','ls-files','hierarchos-vulkan/src',
        'hierarchos-vulkan/shaders','hierarchos-native-cli/src','hierarchos-inference/src',
        'hierarchos-gui/src'],cwd=ROOT,text=True).splitlines():
    sources[name]=digest(ROOT/name)
performance=json.loads((ROOT/'target/rdna-post-gen9-v41-performance/comparison.json').read_text())
generic=json.loads((ROOT/'target/rdna-post-gen9-performance/comparison.json').read_text())
assert generic['pass_'] and len(generic['records'])==72
for arm,p in [('baseline',ROOT/'target/rdna-post-gen9-baseline/v41-handoff.exe'),
              ('candidate',ROOT/'hierarchos-vulkan/target/release/hierarchos-vulkan-deepseek-v41-forward-probe.exe')]:
    assert digest(p)==performance['binaries'][arm]['sha256']
previous=json.loads((ROOT/'hierarchos-vulkan/validation/release_parity/deepseek_v41/receipts/final-push/ab-results.json').read_text())
assert performance['binaries']['baseline']['sha256']==previous['binary_hashes']['candidate']

payloads={}
for label in ['fixture-provenance','fixture-provenance-final','harness-negative-controls',
              'fixture-negative-controls','handoff-negative-controls','runner-negative-controls',
              'release-build','unit-build','v41','vulkan','streaming','offload','kv-cache',
              'qwen-next-backward','package-default','joint-resident','joint-streamed',
              'peft-trajectory','gpt2-native-regression','cli-tests','workspace-check',
              'shader-provenance','push-layouts','forward','generation','gpt2-wide-baseline']:
    payloads[f'gate/{label}.log']=gate/(label+'.log')
for name in ['qualification.json','native-gates.json','shader-provenance.json','gpt2-wide-baseline.json']:
    payloads['gate/'+name]=gate/name
for sub in ['forward','generation']:
    for p in sorted((gate/sub).rglob('*')):
        if p.is_file():payloads[f'{sub}/'+p.relative_to(gate/sub).as_posix()]=p
for label,directory in [('v41','rdna-post-gen9-v41-performance'),('streaming','rdna-post-gen9-performance')]:
    for p in sorted((ROOT/'target'/directory).rglob('*')):
        if p.is_file():payloads[f'performance/{label}/'+p.relative_to(ROOT/'target'/directory).as_posix()]=p
for p in [ROOT/'target/rdna-post-gen9-unit-gates.py',ROOT/'target/rdna-post-gen9-bench.py',Path(__file__).resolve()]:
    payloads['audit-tools/'+p.name]=p
for p in [ROOT/'hierarchos-vulkan/validation/run_rdna3_final_regression.py',
          ROOT/'hierarchos-vulkan/validation/test_rdna3_final_regression.py']:
    payloads['audit-tools/'+p.name]=p
payload_manifest={name:{'sha256':digest(path),'bytes':path.stat().st_size}
                  for name,path in payloads.items()}
with zipfile.ZipFile(out/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,path in payloads.items():
        item=zipfile.ZipInfo(name,(2026,11,2,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(item,path.read_bytes())
    archive.writestr('EVIDENCE-MANIFEST.json',json.dumps(payload_manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'evidence.zip') as archive:
    assert archive.testzip() is None
    for name,expected in payload_manifest.items():
        raw=archive.read(name)
        assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name

report={
 'schema':1,'status':'recorded_v41_and_previous_streaming_scopes_pass_expanded_matrix_incomplete',
 'pass':False,'date':'2026-11-02','recorded_utc':datetime.now(timezone.utc).isoformat(),
 'runtime_revision':base,'runtime_changes_in_this_audit':False,
 'device':{'name':'AMD Radeon Graphics','cpu':'AMD Ryzen Z1 Extreme','vendor_id':0x1002,
           'device_id':0x15bf,'driver':'32.0.31007.6002'},
 'gate':{'absolute_limit':2e-7,'rtol':0,'comparison':'strict_less_than'},
 'scopes':{'v41_native_and_peft':True,'previous_32_streaming_profiles':True,
           'generation_matrix':True,'expanded_forward_matrix':False,'full_registry':False},
 'tests':tests,'v41_numeric':numeric,
 'forward':{'runs':166,'passed':164,'profiles':43,'prior_rdna_profiles':32,'prior_rdna_runs':122,
            'prior_rdna_max_abs':max(r['max_abs'] for r in prior),
            'resident_streaming_word_differences':0,'failures':failures},
 'generation':{'requests':72,'pass':True,'max_abs':max(r['max_abs'] for r in generation['records']),
               'resident_streaming_word_differences':0},
 'existing_gap':{'classification':'pre_existing_not_introduced',
                 'baseline_sha256':baseline_hash,'baseline_binding':str(binding.relative_to(ROOT)).replace('\\','/'),
                 'candidate_sha256':binaries['hierarchos-vulkan-transformer-logits']['sha256'],
                 'compared_words':3840,'different_words':0,'max_abs':failures[0]['max_abs'],
                 'failing_values_per_mode':failures[0]['failing_values']},
 'frozen_original_files_checked':len(frozen),'frozen_original_files_unchanged':True,
 'shader_rebuilds':shader['status_counts'],'push_blocks':429,'host_push_structs':108,
 'workspace':{'all_targets':True,'crates':4,'binaries':65},
 'v41_performance':performance['timings'],'streaming_performance':generic['summary'],
 'performance_limits':['Retained scaled checkpoints, not production throughput',
    'Paired unprofiled observations after builds/tests; host timings vary',
    'Generic baseline supports streaming only; no paired generic resident claim',
    'Unmasked GPT-2-wide timing does not qualify the failing padded case'],
 'binaries':binaries,'sources_sha256':sources,
 'reference_manifests_sha256':{name:digest(ROOT/f'target/rdna-post-gen9-reference/cpu/{name}/manifest.json')
                              for name in ['forward','generation','generation-packages']},
 'evidence':{'path':'evidence.zip','sha256':digest(out/'evidence.zip'),'files':len(payloads)+1,
             'bytes':(out/'evidence.zip').stat().st_size},
 'limits':['The complete expanded RDNA3 matrix remains red; no blanket release qualification',
    'Frozen expectations and tolerance unchanged; numerical experiments discarded',
    'Default V4.1 suite ignores 25 explicit or resource-heavy gates; four explicit gates run separately',
    'Native/GPT-2 cache test filters overlap; test counts must not be blindly summed',
    'SmolLM3 cache requests use its existing full-prefix fallback',
    'CPU comparison excludes existing padded queries; storage identity includes them',
    'Not every registry identifier, precision policy or CPU PEFT architecture is certified',
    'Initial fail-fast runner stopped at forward; remaining native/generation gates were continued separately']}
(out/'qualification.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'evidence':report['evidence'],'v41_numeric':numeric,'scopes':report['scopes']},indent=2))
