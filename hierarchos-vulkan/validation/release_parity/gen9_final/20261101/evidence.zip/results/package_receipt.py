from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import zipfile

root=Path.cwd()
work=root/'target/gen9-final'
out=root/'hierarchos-vulkan/validation/release_parity/gen9_final/20261101'
out.mkdir(parents=True,exist_ok=False)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())
forward=load(work/'forward/qualification.json')
generation=load(work/'generation/qualification.json')
audit=load(work/'audit.json')
closure=load(work/'llama-closure/comparison.json')
architecture=load(work/'architecture-benchmark/benchmark.json')
v41=load(work/'v41-benchmark/comparison.json')
v41_recheck=load(work/'v41-recheck.json')
gates=load(work/'gates.json')
assert all(report['pass'] for report in [forward,generation,audit,closure,architecture])
assert v41_recheck['pass']
assert len(gates)==12 and all(gate['exit']==0 for gate in gates)
assert all(case['reduction_vs_original_percent']>0 and case['reduction_vs_phase4_percent']>0
    and case['reduction_vs_same_binary_unbatched_percent']>0 for case in closure['summary'].values())
test_names=set()
for gate in gates:
    if 'passed' not in gate:continue
    text=(work/(gate['name']+'.log')).read_text()
    for name,tail in re.findall(r'^test (\S+) \.\.\.([^\n]*)',text,re.M):
        if not tail.startswith(' ignored'):test_names.add(name)
assert len(test_names)==269,len(test_names)
load_medians={}
import statistics
for mode in ['resident','default']:
    medians={arm:statistics.median(float(re.search(r'ms=([0-9.]+)',line)[1])
        for record in v41['runs'] if record['arm']==arm and record['residency']==mode and '-pair' in record['log']
        for line in record['context'] if line.startswith('v41_probe_load ')) for arm in ['baseline','candidate']}
    load_medians[mode]={**medians,'candidate_change_percent':100*(medians['candidate']/medians['baseline']-1)}
receipt={'schema':1,'status':'final_gen9_pass_complete_llama_streaming_regression_closed_rdna3_pending',
    'date':'2026-11-01','timezone':'America/Los_Angeles',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'device':{'cpu':'Intel Core i5-6200U','gpu':'Intel HD Graphics 520','vendor_id':'8086',
        'device_id':'1916','driver':'31.0.101.2115'},
    'gate':{'absolute_limit':2e-7,'rtol':0,'comparison':'strict_less_than'},
    'stream_batching':{'target':'physical Intel Gen9 only','upload_window_bytes':1024*1024,
        'fallback':'HIERARCHOS_VULKAN_GEN9_STREAM_BATCH=0',
        'eligibility':'single-tile, non-aliased projections with weight plus bias payload at most 1 MiB',
        'memory_limit':'At most 1 MiB of coalesced small-projection payloads; a following fallback tile may coexist until retirement; allocation padding and arenas are separately observed'},
    'llama_streaming_regression_closed':True,'closure':closure['summary'],
    'forward':{'runs':len(forward['records']),'profiles':len({r['family'] for r in forward['records']}),
        'architectures':forward['native_architectures'],
        'worst_cpu_error':max(r['max_abs'] for r in forward['records']),
        'observable_values':sum(r['values'] for r in forward['records']),
        'excluded_padded_query_values':sum(r['excluded_values'] for r in forward['records']),
        'unmeasured_registry_architectures':forward['unmeasured_registry_architectures']},
    'generation':{'runs':len(generation['records']),'worst_cpu_error':max(r['max_abs'] for r in generation['records']),
        'values':sum(step['values'] for r in generation['records'] for step in r['steps'])},
    'previous_gen9_word_identity':audit['logits'],'distinct_rust_tests':len(test_names),
    'rust_test_names':sorted(test_names),'gates':gates,
    'changed_implementation_from_phase4':audit['changed_implementation'],
    'unchanged_shader_count':len(audit['unchanged_shaders']),
    'shader_rebuild_proof':'Previous 569-active-artifact byte reproduction; all 585 shader files and manifest unchanged',
    'original_frozen_file_count':len(audit['original_fixtures']),
    'frozen_reference_manifests':audit['reference_manifests'],
    'architecture_latency':architecture['summary'],'v41_latency':v41['timings'],'v41_load':load_medians,
    'v41_matched_followup':v41_recheck['summary'],
    'binaries':load(work/'candidate-bin/binaries.json'),'unit_binary':load(work/'unit-binary.json'),
    'limits':['Retained scaled checkpoints, not production throughput',
        'Physical RDNA3 final regression is pending before push',
        '120 registry identifiers remain outside measured numerical coverage',
        'SmolLM3 cached requests use the existing full-prefix fallback',
        'CPU training parity is not extended to every architecture',
        '17 verified fixture-toolchain pins and 54 historical unverified entries remain'],
    'implementation_sha256':{},'evidence':{}}
files={}
def add(path,name):
    assert name not in files,name
    files[name]=path
for folder in [root/'hierarchos-vulkan/src',root/'hierarchos-vulkan/shaders']:
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix in {'.rs','.comp','.glsl','.spv'}:
            name=path.relative_to(root).as_posix()
            receipt['implementation_sha256'][name]=sha(path)
            add(path,'implementation/'+name)
for path in sorted((root/'hierarchos-vulkan/validation').iterdir()):
    if path.is_file() and path.suffix in {'.py','.rs','.ps1','.json','.md'}:
        add(path,'validation/'+path.name)
add(root/'VALIDATION_STATUS.md','VALIDATION_STATUS.md')
add(root/'HANDOFF-MANIFEST.json','frozen-v41/HANDOFF-MANIFEST.json')
for name,label in [('cpu-fixtures-reproduced','forward'),('cpu-fixtures','generation-packages'),
                   ('cpu-generation-complete','generation')]:
    source=root/'target/gen9-phase3'/name
    for path in sorted(source.rglob('*')):
        if path.is_file():add(path,'cpu/'+label+'/'+path.relative_to(source).as_posix())
for folder in ['forward','generation','llama-closure','architecture-benchmark','v41-benchmark']:
    for path in sorted((work/folder).rglob('*')):
        if path.is_file():add(path,'results/'+folder+'/'+path.relative_to(work/folder).as_posix())
for path in sorted(work.iterdir()):
    if path.is_file() and path.suffix in {'.log','.json','.py'}:add(path,'results/'+path.name)
for name in ['shader-provenance.json','shader-provenance.log','fixture-toolchain.log']:
    add(root/'target/gen9-phase4'/name,'previous-proof/'+name)
archive=out/'evidence.zip'
contents={name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name,path in sorted(files.items()):output.write(path,name)
    output.writestr('CONTENTS.json',json.dumps(contents,indent=2)+'\n')
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name,expected in contents.items():
        data=output.read(name)
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
receipt['evidence']={'file':'evidence.zip','bytes':archive.stat().st_size,'sha256':sha(archive),
    'files':len(contents),'all_member_hashes_verified':True}
(out/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'evidence':receipt['evidence'],'distinct_rust_tests':len(test_names),'closure':closure['summary']},indent=2))
