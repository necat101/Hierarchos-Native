from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time

root=Path.cwd()
work=root/'target/gen9-final'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
    return h.hexdigest()
def await_build(name,profile):
    path=work/name
    while True:
        content=path.read_text(errors='replace')
        if re.search(r'Finished [`\']'+profile,content):return content
        if re.search(r'^error(?:\[|:)',content,re.M):raise RuntimeError(content[-4000:])
        time.sleep(2)
records=[]
def run(label,command,tests=False,env=None):
    print('RUN',label,flush=True)
    command=[str(x) for x in command]
    with (work/(label+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
    record={'name':label,'command':command,'exit':result.returncode}
    if tests:
        match=re.search(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',
            (work/(label+'.log')).read_text())
        record.update(passed=int(match[1]) if match else 0,ignored=int(match[2]) if match else 0)
        if not record['passed']:raise RuntimeError(record)
    records.append(record)
    (work/'gates.json').write_text(json.dumps(records,indent=2)+'\n')
    if result.returncode:raise RuntimeError(record)
    print('PASS',label,flush=True)
    return record

content=await_build('build-tests.log','test')
source=Path(re.search(r'Executable .* \(([^\n]+)\)',content)[1])
unit=work/'unit-tests.exe'
shutil.copy2(source,unit)
assert sha(source)==sha(unit)
(work/'unit-binary.json').write_text(json.dumps({'path':str(unit),'sha256':sha(unit)},indent=2)+'\n')
for label,name in [('streaming','parameter_streaming'),('v41','deepseek_v41::'),
    ('offload','weight_offload::tests'),('native-cache','generation_kv_cache_matches_full_prefix'),
    ('qwen-next-backward','qwen3_next_gated_delta_end_to_end_backward_matches_finite_difference'),
    ('vulkan','vulkan::tests')]:
    run(label,[unit,name,'--nocapture','--test-threads=1'],tests=True)
for label,name in [('package-default','deepseek_v41_default_package_scalable_release_strict_all_logits'),
    ('joint-resident','deepseek_v41_joint_depth_and_384_expert_strict_all_logits'),
    ('joint-streamed','deepseek_v41_streamed_vocabulary_joint_strict_all_logits'),
    ('peft-trajectory','deepseek_v41_production_uninterrupted_training_logit_trajectory')]:
    run(label,[unit,name,'--ignored','--nocapture','--test-threads=1'],tests=True)
await_build('build-release.log','release')
bins=work/'candidate-bin'
bins.mkdir()
metadata={}
for name in ['hierarchos-vulkan-transformer-logits','transformer_generation_parity',
             'parameter_streaming_bench','hierarchos-vulkan-deepseek-v41-forward-probe']:
    source=root/'hierarchos-vulkan/target/release'/(name+'.exe')
    digest=sha(source)
    destination=bins/source.name
    shutil.copy2(source,destination)
    assert sha(source)==sha(destination)==digest
    metadata[name]={'path':str(destination),'sha256':digest}
(bins/'binaries.json').write_text(json.dumps(metadata,indent=2)+'\n')
run('forward',[sys.executable,root/'hierarchos-vulkan/validation/qualify_gen9_architectures.py',
    'run','--fixtures',root/'target/gen9-phase3/cpu-fixtures-reproduced',
    '--binary',bins/'hierarchos-vulkan-transformer-logits.exe','--output',work/'forward'])
run('generation',[sys.executable,root/'hierarchos-vulkan/validation/qualify_gen9_generation.py',
    'run','--fixtures',root/'target/gen9-phase3/cpu-generation-complete',
    '--packages',root/'target/gen9-phase3/cpu-fixtures',
    '--binary',bins/'transformer_generation_parity.exe','--output',work/'generation'])
print('PASS COMPLETE QUALIFICATION',flush=True)
