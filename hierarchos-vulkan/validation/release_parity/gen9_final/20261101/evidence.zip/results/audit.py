import hashlib
import json
import zipfile
from pathlib import Path

root=Path.cwd()
work=root/'target/gen9-final'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
prior=json.loads((root/'hierarchos-vulkan/validation/release_parity/gen9_optimizations/20261101/qualification.json').read_text())
result={'pass':False,'logits':{},'changed_implementation':{},'unchanged_shaders':{},'original_fixtures':{}}
for current_name,previous_name in [('forward','candidate-forward'),('generation','candidate-generation')]:
    count=0
    reports=0
    for path in sorted((work/current_name).glob('*.json')):
        if path.name=='qualification.json':continue
        actual=json.loads(path.read_text())['logits_bits']
        expected=json.loads((root/'target/gen9-phase4'/previous_name/path.name).read_text())['logits_bits']
        assert actual==expected,path.name
        count+=sum(len(step) for step in actual) if isinstance(actual[0],list) else len(actual)
        reports+=1
    assert reports=={'forward':166,'generation':72}[current_name]
    result['logits'][current_name]={'reports':reports,'words':count,'differences':0}
for name,expected in prior['implementation_sha256'].items():
    actual=sha(root/name)
    if name.endswith('.spv'):
        assert actual==expected,name
        result['unchanged_shaders'][name]=actual
    elif actual!=expected:result['changed_implementation'][name]={'previous':expected,'current':actual}
assert set(result['changed_implementation'])=={
    'hierarchos-vulkan/src/transformer.rs','hierarchos-vulkan/src/transformer/parameter_streaming_tests.rs',
    'hierarchos-vulkan/src/deepseek_v41/checkpoint.rs'}
manifest=json.loads((root/'HANDOFF-MANIFEST.json').read_text())
for name,expected in manifest.items():
    if name.startswith('hierarchos-vulkan/validation/fixtures/'):
        assert sha(root/name)==expected['sha256'],name
        result['original_fixtures'][name]=expected['sha256']
result['reference_manifests']={name:sha(root/'target/gen9-phase3'/name/'manifest.json')
    for name in ['cpu-fixtures','cpu-fixtures-reproduced','cpu-generation-complete']}
result['previous_receipt_sha256']=sha(root/'hierarchos-vulkan/validation/release_parity/gen9_optimizations/20261101/evidence.zip')
assert result['previous_receipt_sha256']=='04f616ef1a8f79b94e270cfd0d47b1a39573c7f19d219b9256b25b107d1d2b36'
with zipfile.ZipFile(root/'hierarchos-vulkan/validation/release_parity/gen9_optimizations/20261101/evidence.zip') as archive:
    contents=json.loads(archive.read('CONTENTS.json'))
    expected=contents['validation/training_shader_manifest.json']['sha256']
    assert sha(root/'hierarchos-vulkan/validation/training_shader_manifest.json')==expected
    result['unchanged_shader_manifest_sha256']=expected
result['pass']=True
(work/'audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({**result,'unchanged_shaders':len(result['unchanged_shaders']),
    'original_fixtures':len(result['original_fixtures'])},indent=2))
