from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess
import sys

root=Path.cwd()
work=root/'target/gen9-final'
fixtures=root/'target/gen9-phase3/cpu-fixtures-reproduced'
manifest=json.loads((fixtures/'manifest.json').read_text())
sys.path.insert(0,str(root/'hierarchos-vulkan/validation'))
from qualify_gen9_architectures import compare_logits,write_json,digest,validate_residency
def run(label,command):
    print('RUN',label,flush=True)
    with (work/(label+'.log')).open('w') as log:
        result=subprocess.run([str(x) for x in command],stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError(f'{label}: {result.returncode}')
    print('PASS',label,flush=True)

# Match the original exception's checkpoint, and add ordinary Llama/Mistral/
# Qwen2 source-first shapes. Same final executable with batching disabled
# separates scheduling from all prior arithmetic and loader optimizations.
out=work/'llama-closure'
out.mkdir()
arms={
    'original':root/'target/gen9-phase4/baseline-bin/parameter_streaming_bench.exe',
    'phase4':root/'target/gen9-phase4/candidate-bin/parameter_streaming_bench.exe',
    'final':work/'candidate-bin/parameter_streaming_bench.exe',
    'final-unbatched':work/'candidate-bin/parameter_streaming_bench.exe',
}
records=[]
for family in ['llama_wide','llama','mistral','qwen2']:
    case=next(c for c in manifest['cases'] if c['family']==family and c['case']=='unmasked')
    for name,expected in case['files'].items():assert digest(fixtures/name)==expected
    expected=json.loads((fixtures/case['cpu']).read_text())
    words=None
    for pair in range(5):
        order=list(arms)
        if pair%2:order.reverse()
        for arm in order:
            command=[str(arms[arm]),str(fixtures/case['package']),str(fixtures/case['input']),
                '5','31','inference','streaming']
            env={key:value for key,value in os.environ.items()
                if not key.startswith('HIERARCHOS_VULKAN_PROFILE_') and key!='HIERARCHOS_VULKAN_VARIANT_TRACE'}
            if arm=='final-unbatched':env['HIERARCHOS_VULKAN_GEN9_STREAM_BATCH']='0'
            else:env.pop('HIERARCHOS_VULKAN_GEN9_STREAM_BATCH',None)
            process=subprocess.run(command,capture_output=True,text=True,env=env,timeout=300)
            label=f'{family}-{pair}-{arm}'
            (out/(label+'.log')).write_text(process.stderr)
            assert process.returncode==0,label
            report=json.loads(process.stdout)
            validate_residency(report,'streaming')
            check=compare_logits(report['logits_bits'],expected['bits'],expected['visible'])
            assert check['pass'],(label,check)
            if arm=='final':
                assert report['memory_after']['bytes']==report['memory_before']['bytes'],(
                    label,'device allocations grew across warmed forwards')
            if words is not None:assert report['logits_bits']==words,label
            words=report['logits_bits']
            write_json(out/(label+'.json'),report)
            records.append({'family':family,'pair':pair,'arm':arm,'median_ms':report['median_ms'],
                'command':command,'environment_overrides':{'HIERARCHOS_VULKAN_GEN9_STREAM_BATCH':'0'} if arm=='final-unbatched' else {},
                'submissions_per_forward':report['submissions']/report['iterations'],
                'cpu_max_abs':check['max_abs'],'memory_before':report['memory_before'],
                'memory_after':report['memory_after'],'io_before':report['io_before'],'io_after':report['io_after']})
            print('PASS',label,report['median_ms'],report['submissions']/31,flush=True)
            write_json(out/'comparison.json',{'pass':False,'records':records})
summary={}
for family in ['llama_wide','llama','mistral','qwen2']:
    medians={arm:statistics.median(r['median_ms'] for r in records if r['family']==family and r['arm']==arm) for arm in arms}
    summary[family]={**medians,'reduction_vs_original_percent':100*(1-medians['final']/medians['original']),
        'reduction_vs_phase4_percent':100*(1-medians['final']/medians['phase4']),
        'reduction_vs_same_binary_unbatched_percent':100*(1-medians['final']/medians['final-unbatched'])}
write_json(out/'comparison.json',{'pass':True,'records':records,'summary':summary,
    'binaries':{arm:{'path':str(path),'sha256':digest(path)} for arm,path in arms.items()}})
print(json.dumps(summary,indent=2),flush=True)

run('architecture-benchmark',[sys.executable,root/'hierarchos-vulkan/validation/benchmark_gen9_architectures.py',
    '--fixtures',fixtures,'--baseline',arms['original'],'--candidate',arms['final'],'--baseline-resident',
    '--output',work/'architecture-benchmark','--rounds','3','--warmup','5','--iterations','31',
    '--families','gpt2_wide','llama_wide','qwen3_next','qwen3_5_mixed','qwen4_exp_mixed_ple','minimax_m3','dbrx','gpt_oss'])
run('v41-benchmark',[sys.executable,root/'hierarchos-vulkan/validation/benchmark_deepseek_v41_gen9.py',
    '--baseline',root/'target/gen9-phase4/baseline-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe',
    '--candidate',work/'candidate-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe',
    '--output',work/'v41-benchmark','--pairs','3','--steps','2'])
