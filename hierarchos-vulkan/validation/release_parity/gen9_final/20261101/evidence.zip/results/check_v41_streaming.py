from pathlib import Path
import hashlib
import json
import os
import re
import statistics
import subprocess

work=Path('target/gen9-final')
arms={'phase4':Path('target/gen9-phase4/candidate-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe'),
    'final':work/'candidate-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe',
    'final-unbatched-reader':work/'candidate-bin/hierarchos-vulkan-deepseek-v41-forward-probe.exe'}
records=[]
for pair in range(3):
    order=list(arms)
    if pair%2:order.reverse()
    for arm in order:
        env=dict(os.environ)
        if arm=='final-unbatched-reader':env['HIERARCHOS_VULKAN_V41_BATCH_EXPERT_READS']='0'
        command=[str(arms[arm].resolve()),'--residency','default','--prefill','8','--decode','4',
            '--steps','2','--warmup','1']
        completed=subprocess.run(command,capture_output=True,text=True,env=env)
        content=completed.stdout+completed.stderr
        label=f'v41-recheck-{pair}-{arm}'
        (work/(label+'.log')).write_text(content)
        assert completed.returncode==0,label
        digests=re.findall(r'v41_probe_logits .*?digest=([0-9a-f]+)',content)
        assert digests and all(d=='2d2f8e2d5914a0d2' for d in digests),label
        phases=[]
        for line in content.splitlines():
            if line.startswith('v41_probe_phase ') and 'measured=true' in line:
                fields=dict(token.split('=',1) for token in line.split()[1:])
                phases.append({'phase':fields['phase'],'ms':float(fields['ms'])})
        record={'arm':arm,'pair':pair,'command':command,'phases':phases,
            'load_ms':float(re.search(r'v41_probe_load ms=([0-9.]+)',content)[1])}
        records.append(record)
        (work/'v41-recheck.json').write_text(json.dumps({'pass':False,'records':records},indent=2)+'\n')
        print('PASS',label,{phase:statistics.median(p['ms'] for p in phases if p['phase']==phase)
            for phase in ['prefill','decode']},flush=True)
summary={arm:{phase:statistics.median(p['ms'] for r in records if r['arm']==arm
    for p in r['phases'] if p['phase']==phase) for phase in ['prefill','decode']} for arm in arms}
summary['final_change_vs_phase4_percent']={phase:100*(summary['final'][phase]/summary['phase4'][phase]-1)
    for phase in ['prefill','decode']}
(work/'v41-recheck.json').write_text(json.dumps({'pass':True,'records':records,'summary':summary,
    'binaries':{arm:hashlib.sha256(path.read_bytes()).hexdigest() for arm,path in arms.items()}},indent=2)+'\n')
print(json.dumps(summary,indent=2))
