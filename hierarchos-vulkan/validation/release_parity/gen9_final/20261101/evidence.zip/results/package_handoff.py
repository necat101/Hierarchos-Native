from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

root=Path.cwd()
archive=root/'.tools/gen9-final-rdna3-handoff-20261101.zip'
names=set()
for command in [['git','diff','--name-only','-z','HEAD'],['git','ls-files','--others','--exclude-standard','-z']]:
    names.update(name for name in subprocess.check_output(command).decode().split('\0') if name)
files={}
deleted=[]
for name in sorted(names):
    path=root/name
    if not path.exists():deleted.append(name);continue
    assert path.is_file(),name
    files[name]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
manifest={'schema':1,'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'deleted_paths':deleted,
    'scope':'Complete final Gen9 working-tree changes from the handoff base; no Git metadata or build caches',
    'qualification':'hierarchos-vulkan/validation/GEN9_FINAL_RECEIPT.md',
    'pending':'Physical RDNA3 final regression before push; Gen9 Llama streaming closure is qualified'}
assert not deleted,'This overlay intentionally does not automate deletion'
readme='''# Gen9 to RDNA3 working-tree handoff

This archive contains the current uncommitted changes from base
2695c93e21b47ed9657c6793228aeb5d1b67e562, including the preceding Gen9 port phases.
HANDOFF.json binds every overlay file. Extract into a separate staging directory,
review against a checkout of that base, then copy the overlay into that checkout.
Preserve any local work before applying files. No Git metadata is included.

Read overlay/hierarchos-vulkan/validation/GEN9_FINAL_RECEIPT.md for the final
Llama streaming closure, measured memory and performance, and the RDNA3 command.
Earlier receipts retain their historical results. The final evidence ZIP contains portable frozen CPU
references. The RDNA3 runner rebuilds locally and requires the known PCI ID.
Python's standard library is sufficient to consume the frozen references.

No push or new physical RDNA3 qualification has been performed on this Gen9 host.
'''
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for name in files:output.write(root/name,'overlay/'+name)
    output.writestr('HANDOFF.json',json.dumps(manifest,indent=2)+'\n')
    output.writestr('README.md',readme)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name,expected in files.items():
        data=output.read('overlay/'+name)
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],name
receipt={'path':str(archive),'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),
    'all_member_hashes_verified':True}
(root/'target/gen9-final/handoff.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
