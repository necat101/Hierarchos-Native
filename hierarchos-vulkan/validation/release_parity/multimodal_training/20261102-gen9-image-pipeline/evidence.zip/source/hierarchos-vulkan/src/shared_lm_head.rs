use std::{
    path::Path,
    sync::{
        atomic::{AtomicU32, Ordering},
        Arc, Mutex,
    },
};

use anyhow::{bail, Context, Result};
use bytemuck::{Pod, Zeroable};

use crate::mixed_precision::{VulkanParameterStorageMirror, VulkanParameterStorageMirrorRefresher};
use crate::weight_offload::ModelPackage;
use crate::{
    read_f32_tensor, vendor, vulkan, AdamWHyperParams, GpuBuffer, VulkanDevice,
    VulkanParameterStorageFormat,
};

const GRADIENT_ACCUMULATE_SPV: &[u8] = include_bytes!("../shaders/gradient_accumulate.spv");
const ADAMW_RANGE_SPV: &[u8] = include_bytes!("../shaders/adamw_range.spv");

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct LenPush {
    len: u32,
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct AdamWPush {
    len: u32,
    step: u32,
    lr: f32,
    beta1: f32,
    beta2: f32,
    eps: f32,
    weight_decay: f32,
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct AdamWRangePush {
    offset: u32,
    len: u32,
    step: u32,
    lr: f32,
    beta1: f32,
    beta2: f32,
    eps: f32,
    weight_decay: f32,
}

struct SharedLmHeadInner {
    device: VulkanDevice,
    context_dim: usize,
    vocab_size: usize,
    weight: GpuBuffer,
    package_source: Option<SharedLmHeadPackageSource>,
    training_state: Mutex<Option<SharedLmHeadTrainingState>>,
    readback: GpuBuffer,
    execution_mirror: Mutex<Option<SharedLmHeadExecutionMirror>>,
    step: AtomicU32,
    gradient_accumulate: vulkan::ComputeKernel,
    adamw: vulkan::ComputeKernel,
    adamw_range: vulkan::ComputeKernel,
}

struct SharedLmHeadPackageSource {
    package: Arc<Mutex<ModelPackage>>,
    name: String,
}

#[derive(Clone)]
struct SharedLmHeadTrainingState {
    accumulated_grad: GpuBuffer,
    exp_avg: GpuBuffer,
    exp_avg_sq: GpuBuffer,
}

struct SharedLmHeadExecutionMirror {
    mirror: VulkanParameterStorageMirror,
    refresher: VulkanParameterStorageMirrorRefresher,
}

/// One physical and optimizer identity for Hierarchos' tied
/// `lm_head.weight` parameter.
///
/// Clones share the same Vulkan weight allocation, gradient accumulator,
/// AdamW first/second moments, and step counter. This lets H-DeepEmbed,
/// L-DeepEmbed, and the LM-head loss bind the exact same parameter without
/// duplicating Vulkan handles or silently training divergent copies.
/// In the inference-only package tier, clones instead share one immutable
/// package table; resident buffer access and all parameter mutations fail.
#[derive(Clone)]
pub struct SharedLmHeadParameter {
    inner: Arc<SharedLmHeadInner>,
}

impl SharedLmHeadParameter {
    pub fn new(
        device: VulkanDevice,
        context_dim: usize,
        vocab_size: usize,
        weight: &[f32],
    ) -> Result<Self> {
        if context_dim == 0 || vocab_size == 0 {
            bail!("shared lm_head context_dim and vocab_size must be positive");
        }
        let len = context_dim
            .checked_mul(vocab_size)
            .context("shared lm_head element count overflow")?;
        if weight.len() != len {
            bail!(
                "shared lm_head weight has {} values; expected {len} for [{vocab_size}, {context_dim}]",
                weight.len()
            );
        }
        if weight.iter().any(|value| !value.is_finite()) {
            bail!("shared lm_head weight contains non-finite values");
        }

        let weight = GpuBuffer::from_f32(&device, weight)?;
        Self::from_weight_buffer(device, context_dim, vocab_size, weight, true, None)
    }

    fn from_weight_buffer(
        device: VulkanDevice,
        context_dim: usize,
        vocab_size: usize,
        weight: GpuBuffer,
        trainable: bool,
        package_source: Option<SharedLmHeadPackageSource>,
    ) -> Result<Self> {
        let len = context_dim
            .checked_mul(vocab_size)
            .context("shared lm_head element count overflow")?;
        if package_source.is_none() && weight.f32_capacity() < len {
            bail!(
                "shared lm_head Vulkan weight capacity {} is smaller than required {len}",
                weight.f32_capacity()
            );
        }
        let training_state = if trainable {
            Some(SharedLmHeadTrainingState {
                accumulated_grad: GpuBuffer::zeros_f32(&device, len)?,
                exp_avg: GpuBuffer::zeros_f32(&device, len)?,
                exp_avg_sq: GpuBuffer::zeros_f32(&device, len)?,
            })
        } else {
            None
        };
        Ok(Self {
            inner: Arc::new(SharedLmHeadInner {
                gradient_accumulate: vulkan::ComputeKernel::new(
                    &device,
                    GRADIENT_ACCUMULATE_SPV,
                    2,
                    std::mem::size_of::<LenPush>() as u32,
                )?,
                adamw: vendor::adamw_kernel(&device)?,
                adamw_range: vulkan::ComputeKernel::new(
                    &device,
                    ADAMW_RANGE_SPV,
                    4,
                    std::mem::size_of::<AdamWRangePush>() as u32,
                )?,
                weight,
                readback: GpuBuffer::zeros_host_f32(
                    &device,
                    if package_source.is_some() { 1 } else { len },
                )?,
                package_source,
                training_state: Mutex::new(training_state),
                execution_mirror: Mutex::new(None),
                step: AtomicU32::new(0),
                device,
                context_dim,
                vocab_size,
            }),
        })
    }

    /// Create an adapter-local copy of the tied embedding/head parameter
    /// without staging the full table through host memory. The fork owns an
    /// independent Vulkan weight allocation and, when trainable, independent
    /// gradient and AdamW moment buffers.
    pub(crate) fn fork_for_peft_replacement(&self, trainable: bool) -> Result<Self> {
        self.require_resident("PEFT replacement")?;
        let weight = self.inner.weight.duplicate_f32(self.len())?;
        Self::from_weight_buffer(
            self.inner.device.clone(),
            self.inner.context_dim,
            self.inner.vocab_size,
            weight,
            trainable,
            None,
        )
    }

    /// One immutable package identity shared by token lookup and tied projection.
    /// The caller proves equality with the loaded table before rebinding either edge.
    pub(crate) fn from_tiered_package(
        device: VulkanDevice,
        context_dim: usize,
        vocab_size: usize,
        package: Arc<Mutex<ModelPackage>>,
        name: String,
    ) -> Result<Self> {
        Self::from_package_rows(device, context_dim, vocab_size, package, name, false)
    }

    /// A logical input vocabulary may exclude reserved rows in the physical
    /// checkpoint table. They remain in the source for wrapper export, but are
    /// neither addressable by lookup nor returned as this parameter's weights.
    pub(crate) fn from_tiered_package_prefix(
        device: VulkanDevice,
        context_dim: usize,
        vocab_size: usize,
        package: Arc<Mutex<ModelPackage>>,
        name: String,
    ) -> Result<Self> {
        Self::from_package_rows(device, context_dim, vocab_size, package, name, true)
    }

    fn from_package_rows(
        device: VulkanDevice,
        context_dim: usize,
        vocab_size: usize,
        package: Arc<Mutex<ModelPackage>>,
        name: String,
        allow_row_prefix: bool,
    ) -> Result<Self> {
        let shape = package
            .lock()
            .map_err(|_| anyhow::anyhow!("shared weight package lock poisoned"))?
            .shape(&name)?;
        let geometry_matches = matches!(shape.as_slice(), [rows, cols]
            if *cols == context_dim && (*rows == vocab_size || (allow_row_prefix && *rows >= vocab_size)));
        if context_dim == 0 || vocab_size == 0 || !geometry_matches {
            bail!("package-backed shared lm_head geometry mismatch");
        }
        let placeholder = GpuBuffer::zeros_f32(&device, 1)?;
        Self::from_weight_buffer(
            device,
            context_dim,
            vocab_size,
            placeholder,
            false,
            Some(SharedLmHeadPackageSource { package, name }),
        )
    }

    pub(crate) fn is_package_backed(&self) -> bool {
        self.inner.package_source.is_some()
    }

    fn require_resident(&self, operation: &str) -> Result<()> {
        if let Some(source) = self.inner.package_source.as_ref() {
            bail!("package-backed vocabulary parameter {} does not support {operation}; reload resident weights first", source.name);
        }
        Ok(())
    }

    pub(crate) fn gather_package_rows(&self, row_ids: &[u32]) -> Result<Vec<f32>> {
        if let Some(id) = row_ids
            .iter()
            .find(|&&id| id as usize >= self.inner.vocab_size)
        {
            bail!(
                "input row {id} is outside logical vocabulary size {}",
                self.inner.vocab_size
            );
        }
        let source = self
            .inner
            .package_source
            .as_ref()
            .context("shared lm_head has no package source")?;
        let mut package = source
            .package
            .lock()
            .map_err(|_| anyhow::anyhow!("shared weight package lock poisoned"))?;
        let dtype = package.entry(&source.name)?.dtype;
        let rows = row_ids.iter().map(|&id| id as usize).collect::<Vec<_>>();
        let raw = package.read_row_gather(&source.name, &rows)?;
        ModelPackage::decode_f32(dtype, &raw)
    }

    pub fn from_model_package(device: VulkanDevice, model_dir: impl AsRef<Path>) -> Result<Self> {
        let path = model_dir.as_ref().join("model.safetensors");
        let (shape, weight) = read_f32_tensor(&path, "lm_head.weight")?;
        let (vocab_size, context_dim) = match shape.as_slice() {
            [vocab_size, context_dim] if *vocab_size > 0 && *context_dim > 0 => {
                (*vocab_size, *context_dim)
            }
            _ => bail!("lm_head.weight must have shape [vocab_size, context_dim], got {shape:?}"),
        };
        Self::new(device, context_dim, vocab_size, &weight)
    }

    pub fn context_dim(&self) -> usize {
        self.inner.context_dim
    }

    pub fn vocab_size(&self) -> usize {
        self.inner.vocab_size
    }

    pub fn step(&self) -> u32 {
        self.inner.step.load(Ordering::Relaxed)
    }

    pub fn device_name(&self) -> &str {
        self.inner.device.name()
    }

    pub fn shares_identity_with(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.inner, &other.inner)
    }

    pub fn weights(&self) -> Result<Vec<f32>> {
        if let Some(source) = self.inner.package_source.as_ref() {
            return source
                .package
                .lock()
                .map_err(|_| anyhow::anyhow!("shared weight package lock poisoned"))?
                .read_f32_row_prefix(&source.name, self.inner.vocab_size);
        }
        self.inner.weight.read_f32(self.len())
    }

    /// Bounded canonical FP32 reads for checkpoint identity. Logical bounds
    /// deliberately exclude any reserved rows in a wrapper's physical table.
    pub(crate) fn weight_rows(&self, first: usize, rows: usize) -> Result<Vec<f32>> {
        if rows == 0
            || first
                .checked_add(rows)
                .is_none_or(|end| end > self.vocab_size())
        {
            anyhow::bail!("shared vocabulary row range is outside its logical shape");
        }
        if let Some(source) = self.inner.package_source.as_ref() {
            return source
                .package
                .lock()
                .map_err(|_| anyhow::anyhow!("shared weight package lock poisoned"))?
                .read_f32_rows(&source.name, first, rows);
        }
        let len = rows * self.context_dim();
        let output = GpuBuffer::uninitialized_host_f32(&self.inner.device, len)?;
        let mut commands = crate::vulkan::ComputeBatch::new(&self.inner.device)?;
        commands.readback_f32_range(
            &self.inner.weight,
            first * self.context_dim(),
            &output,
            0,
            len,
        )?;
        commands.submit()?;
        output.read_f32(len)
    }

    pub(crate) fn weight_buffer(&self) -> Result<&GpuBuffer> {
        self.require_resident("resident buffer access")?;
        Ok(&self.inner.weight)
    }

    pub(crate) fn install_fp16_parameter_storage_mirror(
        &self,
        mirror: VulkanParameterStorageMirror,
    ) -> Result<()> {
        self.require_resident("FP16 execution mirrors")?;
        if mirror.format() != VulkanParameterStorageFormat::Fp16 {
            bail!(
                "shared lm_head execution mirror must be fp16; got {}",
                mirror.format().label()
            );
        }
        if mirror.len() != self.len() {
            bail!(
                "shared lm_head execution mirror has {} elements; expected {}",
                mirror.len(),
                self.len()
            );
        }
        let mut execution_mirror = self
            .inner
            .execution_mirror
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head execution mirror lock poisoned"))?;
        if let Some(existing) = execution_mirror.as_ref() {
            if !existing
                .mirror
                .packed_storage()
                .shares_allocation_with(mirror.packed_storage())
            {
                bail!("shared lm_head already has a different packed execution mirror");
            }
            return Ok(());
        }
        *execution_mirror = Some(SharedLmHeadExecutionMirror {
            refresher: VulkanParameterStorageMirrorRefresher::new(
                &self.inner.device,
                VulkanParameterStorageFormat::Fp16,
            )?,
            mirror,
        });
        Ok(())
    }

    pub(crate) fn fp16_parameter_storage_mirror(
        &self,
    ) -> Result<Option<VulkanParameterStorageMirror>> {
        let execution_mirror = self
            .inner
            .execution_mirror
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head execution mirror lock poisoned"))?;
        Ok(execution_mirror
            .as_ref()
            .map(|execution| execution.mirror.clone()))
    }

    pub fn fp16_parameter_storage_active(&self) -> bool {
        self.inner
            .execution_mirror
            .lock()
            .map(|mirror| mirror.is_some())
            .unwrap_or(false)
    }

    /// Diagnostic expansion of the compact execution mirror. Checkpoints and
    /// optimizer state still use `weights()` from the canonical FP32 master.
    pub fn fp16_parameter_storage_values(&self) -> Result<Option<Vec<f32>>> {
        let mirror = self.fp16_parameter_storage_mirror()?;
        mirror
            .map(|mirror| mirror.read_expanded_f32(&self.inner.device))
            .transpose()
    }

    pub(crate) fn device(&self) -> VulkanDevice {
        self.inner.device.clone()
    }

    fn training_state(&self) -> Result<SharedLmHeadTrainingState> {
        self.require_resident("training")?;
        self.inner
            .training_state
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head training-state lock poisoned"))?
            .as_ref()
            .cloned()
            .context("shared lm_head training state is not allocated")
    }

    pub(crate) fn release_training_state(&self) -> Result<()> {
        *self
            .inner
            .training_state
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head training-state lock poisoned"))? = None;
        Ok(())
    }

    pub(crate) fn training_state_bytes(&self) -> Result<usize> {
        Ok(self
            .inner
            .training_state
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head training-state lock poisoned"))?
            .as_ref()
            .map(|_| 3 * self.len() * std::mem::size_of::<f32>())
            .unwrap_or(0))
    }

    pub(crate) fn peft_optimizer_buffers(&self) -> Result<(GpuBuffer, GpuBuffer)> {
        let state = self.training_state()?;
        Ok((state.exp_avg, state.exp_avg_sq))
    }

    pub(crate) fn restore_peft_optimizer_step(&self, step: u32) {
        self.inner.step.store(step, Ordering::Relaxed);
    }

    pub(crate) fn gradient_buffer(&self) -> Result<GpuBuffer> {
        Ok(self.training_state()?.accumulated_grad)
    }

    pub(crate) fn record_zero_grad(&self, commands: &mut vulkan::ComputeBatch) -> Result<()> {
        let state = self.training_state()?;
        commands.fill_zero_f32(&state.accumulated_grad, self.len())
    }

    pub(crate) fn record_accumulate_gradient(
        &self,
        commands: &mut vulkan::ComputeBatch,
        gradient: &GpuBuffer,
    ) -> Result<()> {
        let state = self.training_state()?;
        let push = LenPush {
            len: self.len() as u32,
        };
        self.inner.gradient_accumulate.record_dispatch(
            commands,
            &[&state.accumulated_grad, gradient],
            bytemuck::bytes_of(&push),
            [div_ceil_u32(self.len(), 256), 1, 1],
        )
    }

    pub(crate) fn record_step(
        &self,
        commands: &mut vulkan::ComputeBatch,
        hyper: AdamWHyperParams,
    ) -> Result<u32> {
        self.record_step_policy(commands, hyper, None)
    }

    pub(crate) fn record_step_with_cpu_policy(
        &self, commands: &mut vulkan::ComputeBatch, hyper: crate::CpuAdamWHyperParams,
        kernel: &crate::cpu_adamw::CpuAdamW,
    ) -> Result<u32> {
        hyper.validate()?;
        self.record_step_policy(commands, hyper.as_f32(), Some((hyper, kernel)))
    }

    fn record_step_policy(
        &self, commands: &mut vulkan::ComputeBatch, hyper: AdamWHyperParams,
        policy: Option<(crate::CpuAdamWHyperParams, &crate::cpu_adamw::CpuAdamW)>,
    ) -> Result<u32> {
        hyper.validate()?;
        let state = self.training_state()?;
        let previous = self
            .inner
            .step
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |step| {
                step.checked_add(1)
            })
            .map_err(|_| anyhow::anyhow!("shared lm_head AdamW step overflow"))?;
        let next_step = previous + 1;
        let push = AdamWPush {
            len: self.len() as u32,
            step: next_step,
            lr: hyper.lr,
            beta1: hyper.beta1,
            beta2: hyper.beta2,
            eps: hyper.eps,
            weight_decay: hyper.weight_decay,
        };
        if let Some((config, kernel)) = policy {
            kernel.record_step(commands, &self.inner.weight, &state.accumulated_grad,
                &state.exp_avg, &state.exp_avg_sq, self.len(), next_step, config, true)?;
        } else { self.inner.adamw.record_dispatch(
            commands,
            &[
                &self.inner.weight,
                &state.accumulated_grad,
                &state.exp_avg,
                &state.exp_avg_sq,
            ],
            bytemuck::bytes_of(&push),
            [div_ceil_u32(self.len(), 256), 1, 1],
        )?; }
        let execution_mirror = self
            .inner
            .execution_mirror
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head execution mirror lock poisoned"))?;
        if let Some(execution) = execution_mirror.as_ref() {
            execution
                .refresher
                .record_refresh(commands, &self.inner.weight, &execution.mirror)?;
        }
        Ok(next_step)
    }

    /// Applies one AdamW generation only to selected vocabulary rows.
    ///
    /// PEFT's `trainable_token_indices` stores replacement embedding rows and
    /// leaves every other base row frozen. Dispatching the existing range
    /// AdamW kernel once per selected row preserves that contract exactly,
    /// including decoupled weight decay and optimizer moments, without a
    /// host-side gradient mask or a full-table update/restore pass.
    pub(crate) fn record_step_rows(
        &self,
        commands: &mut vulkan::ComputeBatch,
        hyper: AdamWHyperParams,
        rows: &[usize],
    ) -> Result<u32> {
        hyper.validate()?;
        let state = self.training_state()?;
        if rows.is_empty() {
            bail!("shared lm_head selective AdamW requires at least one row");
        }
        if rows.iter().any(|&row| row >= self.inner.vocab_size) {
            bail!(
                "shared lm_head selective AdamW row is outside vocabulary size {}",
                self.inner.vocab_size
            );
        }
        let previous = self
            .inner
            .step
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |step| {
                step.checked_add(1)
            })
            .map_err(|_| anyhow::anyhow!("shared lm_head AdamW step overflow"))?;
        let next_step = previous + 1;
        for &row in rows {
            let offset = row
                .checked_mul(self.inner.context_dim)
                .context("shared lm_head selective AdamW row offset overflow")?;
            let push = AdamWRangePush {
                offset: u32::try_from(offset)
                    .context("shared lm_head selective AdamW offset exceeds u32")?,
                len: u32::try_from(self.inner.context_dim)
                    .context("shared lm_head selective AdamW row width exceeds u32")?,
                step: next_step,
                lr: hyper.lr,
                beta1: hyper.beta1,
                beta2: hyper.beta2,
                eps: hyper.eps,
                weight_decay: hyper.weight_decay,
            };
            self.inner.adamw_range.record_dispatch(
                commands,
                &[
                    &self.inner.weight,
                    &state.accumulated_grad,
                    &state.exp_avg,
                    &state.exp_avg_sq,
                ],
                bytemuck::bytes_of(&push),
                [div_ceil_u32(self.inner.context_dim, 256), 1, 1],
            )?;
        }
        let execution_mirror = self
            .inner
            .execution_mirror
            .lock()
            .map_err(|_| anyhow::anyhow!("shared lm_head execution mirror lock poisoned"))?;
        if let Some(execution) = execution_mirror.as_ref() {
            execution
                .refresher
                .record_refresh(commands, &self.inner.weight, &execution.mirror)?;
        }
        Ok(next_step)
    }

    /// Replaces selected vocabulary rows in-place, preserving the physical
    /// identity shared by the token embedding and tied LM head.
    pub(crate) fn replace_rows(&self, rows: &[usize], values: &[f32]) -> Result<()> {
        self.require_resident("row replacement")?;
        if rows.is_empty() {
            bail!("shared lm_head row replacement requires at least one row");
        }
        let expected = rows
            .len()
            .checked_mul(self.inner.context_dim)
            .context("shared lm_head row replacement size overflow")?;
        if values.len() != expected {
            bail!(
                "shared lm_head row replacement has {} values; expected {expected}",
                values.len()
            );
        }
        if rows.iter().any(|&row| row >= self.inner.vocab_size) {
            bail!(
                "shared lm_head row replacement contains an index outside vocabulary size {}",
                self.inner.vocab_size
            );
        }
        if values.iter().any(|value| !value.is_finite()) {
            bail!("shared lm_head row replacement contains non-finite values");
        }
        let mut weight = self.weights()?;
        for (source_row, &target_row) in rows.iter().enumerate() {
            let source_start = source_row * self.inner.context_dim;
            let target_start = target_row * self.inner.context_dim;
            weight[target_start..target_start + self.inner.context_dim]
                .copy_from_slice(&values[source_start..source_start + self.inner.context_dim]);
        }
        self.inner.weight.write_f32(&weight)?;
        if self.fp16_parameter_storage_active() {
            let mut commands = vulkan::ComputeBatch::new(&self.inner.device)?;
            let execution_mirror =
                self.inner.execution_mirror.lock().map_err(|_| {
                    anyhow::anyhow!("shared lm_head execution mirror lock poisoned")
                })?;
            if let Some(execution) = execution_mirror.as_ref() {
                execution.refresher.record_refresh(
                    &mut commands,
                    &self.inner.weight,
                    &execution.mirror,
                )?;
            }
            drop(execution_mirror);
            commands.submit()?;
        }
        Ok(())
    }

    /// Replaces the complete shared token table in-place.
    ///
    /// PEFT's `ModulesToSaveWrapper` can wrap an input `nn.Embedding`, in
    /// which case the adapter checkpoint contains the complete cloned
    /// embedding weight rather than a trainable-token delta. Keep the native
    /// token lookup bound to the same physical allocation while replacing its
    /// contents, and refresh an optional compact execution mirror exactly as
    /// the row-selective path does.
    pub(crate) fn replace_weights(&self, values: &[f32]) -> Result<()> {
        self.require_resident("weight replacement")?;
        if values.len() != self.len() {
            bail!(
                "shared lm_head replacement has {} values; expected {}",
                values.len(),
                self.len()
            );
        }
        if values.iter().any(|value| !value.is_finite()) {
            bail!("shared lm_head replacement contains non-finite values");
        }
        self.inner.weight.write_f32(values)?;
        if self.fp16_parameter_storage_active() {
            let mut commands = vulkan::ComputeBatch::new(&self.inner.device)?;
            let execution_mirror =
                self.inner.execution_mirror.lock().map_err(|_| {
                    anyhow::anyhow!("shared lm_head execution mirror lock poisoned")
                })?;
            if let Some(execution) = execution_mirror.as_ref() {
                execution.refresher.record_refresh(
                    &mut commands,
                    &self.inner.weight,
                    &execution.mirror,
                )?;
            }
            drop(execution_mirror);
            commands.submit()?;
        }
        Ok(())
    }

    pub(crate) fn record_readback(&self, commands: &mut vulkan::ComputeBatch) -> Result<()> {
        if self.is_package_backed() {
            return Ok(());
        }
        commands.readback_f32(&self.inner.weight, &self.inner.readback, self.len())
    }

    pub(crate) fn read_recorded_weights(&self) -> Result<Vec<f32>> {
        if self.is_package_backed() {
            return self.weights();
        }
        self.inner.readback.read_f32(self.len())
    }

    fn len(&self) -> usize {
        self.inner.context_dim * self.inner.vocab_size
    }
}

fn div_ceil_u32(value: usize, divisor: usize) -> u32 {
    value.div_ceil(divisor) as u32
}
